package com.mavp.pojos.locations;

public class Locations {
	private Licenseform licenseform;

    private Locationinfoform locationinfoform;

    public void setLicenseform(Licenseform licenseform){
        this.licenseform = licenseform;
    }
    public Licenseform getLicenseform(){
        return this.licenseform;
    }
    public void setLocationinfoform(Locationinfoform locationinfoform){
        this.locationinfoform = locationinfoform;
    }
    public Locationinfoform getLocationinfoform(){
        return this.locationinfoform;
    }

}
