package com.mavp.pojos.locations;

import java.util.List;

public class RequestJSON {
	    private Enrolleeform enrolleeform;
	    private AdditionalInfo additionalinfo;
	   
		public AdditionalInfo getAdditionalinfo() {
			return additionalinfo;
		}
		public void setAdditionalinfo(AdditionalInfo additionalinfo) {
			this.additionalinfo = additionalinfo;
		}
		private List<Locations> locations;
     
	   
		
		public void setEnrolleeform(Enrolleeform enrolleeform){
	        this.enrolleeform = enrolleeform;
	    }
	    public Enrolleeform getEnrolleeform(){
	        return this.enrolleeform;
	    }
	    public void setLocations(List<Locations> locations){
	        this.locations = locations;
	    }
	    public List<Locations> getLocations(){
	        return this.locations;
	    }

}
