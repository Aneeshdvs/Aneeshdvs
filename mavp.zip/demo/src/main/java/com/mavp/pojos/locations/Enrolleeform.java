package com.mavp.pojos.locations;

public class Enrolleeform {
    private String enrolleeForm_organization;

    private String enrolleeForm_address1;

    private String enrolleeForm_address2;

    private String enrolleeForm_city;

    private String enrolleeForm_state;

    private String enrolleeForm_zip;

    private String enrolleeForm_salutation;

    private String enrolleeForm_professionaldesignation;

    private String enrolleeForm_firstname;

    private String enrolleeForm_middleinitial;

    private String enrolleeForm_lastname;

    private String enrolleeForm_generationalsuffix;

    private String enrolleeForm_phoneareacode;

    private String enrolleeForm_phoneexchange;

    private String enrolleeForm_phonelinenumber;

    private String enrolleeForm_faxareacode;

    private String enrolleeForm_faxexchange;

    private String enrolleeForm_faxlinenumber;

    private String enrolleeForm_email;

    private String enrolleeForm_emailverify;

    private String enrolleeForm_accept;

    private String enrolleeForm_acknowledge;

    private String enrolleeForm_authorize;

    public void setEnrolleeForm_organization(String enrolleeForm_organization){
        this.enrolleeForm_organization = enrolleeForm_organization;
    }
    public String getEnrolleeForm_organization(){
        return this.enrolleeForm_organization;
    }
    public void setEnrolleeForm_address1(String enrolleeForm_address1){
        this.enrolleeForm_address1 = enrolleeForm_address1;
    }
    public String getEnrolleeForm_address1(){
        return this.enrolleeForm_address1;
    }
    public void setEnrolleeForm_address2(String enrolleeForm_address2){
        this.enrolleeForm_address2 = enrolleeForm_address2;
    }
    public String getEnrolleeForm_address2(){
        return this.enrolleeForm_address2;
    }
    public void setEnrolleeForm_city(String enrolleeForm_city){
        this.enrolleeForm_city = enrolleeForm_city;
    }
    public String getEnrolleeForm_city(){
        return this.enrolleeForm_city;
    }
    public void setEnrolleeForm_state(String enrolleeForm_state){
        this.enrolleeForm_state = enrolleeForm_state;
    }
    public String getEnrolleeForm_state(){
        return this.enrolleeForm_state;
    }
    public void setEnrolleeForm_zip(String enrolleeForm_zip){
        this.enrolleeForm_zip = enrolleeForm_zip;
    }
    public String getEnrolleeForm_zip(){
        return this.enrolleeForm_zip;
    }
    public void setEnrolleeForm_salutation(String enrolleeForm_salutation){
        this.enrolleeForm_salutation = enrolleeForm_salutation;
    }
    public String getEnrolleeForm_salutation(){
        return this.enrolleeForm_salutation;
    }
    public void setEnrolleeForm_professionaldesignation(String enrolleeForm_professionaldesignation){
        this.enrolleeForm_professionaldesignation = enrolleeForm_professionaldesignation;
    }
    public String getEnrolleeForm_professionaldesignation(){
        return this.enrolleeForm_professionaldesignation;
    }
    public void setEnrolleeForm_firstname(String enrolleeForm_firstname){
        this.enrolleeForm_firstname = enrolleeForm_firstname;
    }
    public String getEnrolleeForm_firstname(){
        return this.enrolleeForm_firstname;
    }
    public void setEnrolleeForm_middleinitial(String enrolleeForm_middleinitial){
        this.enrolleeForm_middleinitial = enrolleeForm_middleinitial;
    }
    public String getEnrolleeForm_middleinitial(){
        return this.enrolleeForm_middleinitial;
    }
    public void setEnrolleeForm_lastname(String enrolleeForm_lastname){
        this.enrolleeForm_lastname = enrolleeForm_lastname;
    }
    public String getEnrolleeForm_lastname(){
        return this.enrolleeForm_lastname;
    }
    public void setEnrolleeForm_generationalsuffix(String enrolleeForm_generationalsuffix){
        this.enrolleeForm_generationalsuffix = enrolleeForm_generationalsuffix;
    }
    public String getEnrolleeForm_generationalsuffix(){
        return this.enrolleeForm_generationalsuffix;
    }
    public void setEnrolleeForm_phoneareacode(String enrolleeForm_phoneareacode){
        this.enrolleeForm_phoneareacode = enrolleeForm_phoneareacode;
    }
    public String getEnrolleeForm_phoneareacode(){
        return this.enrolleeForm_phoneareacode;
    }
    public void setEnrolleeForm_phoneexchange(String enrolleeForm_phoneexchange){
        this.enrolleeForm_phoneexchange = enrolleeForm_phoneexchange;
    }
    public String getEnrolleeForm_phoneexchange(){
        return this.enrolleeForm_phoneexchange;
    }
    public void setEnrolleeForm_phonelinenumber(String enrolleeForm_phonelinenumber){
        this.enrolleeForm_phonelinenumber = enrolleeForm_phonelinenumber;
    }
    public String getEnrolleeForm_phonelinenumber(){
        return this.enrolleeForm_phonelinenumber;
    }
    public void setEnrolleeForm_faxareacode(String enrolleeForm_faxareacode){
        this.enrolleeForm_faxareacode = enrolleeForm_faxareacode;
    }
    public String getEnrolleeForm_faxareacode(){
        return this.enrolleeForm_faxareacode;
    }
    public void setEnrolleeForm_faxexchange(String enrolleeForm_faxexchange){
        this.enrolleeForm_faxexchange = enrolleeForm_faxexchange;
    }
    public String getEnrolleeForm_faxexchange(){
        return this.enrolleeForm_faxexchange;
    }
    public void setEnrolleeForm_faxlinenumber(String enrolleeForm_faxlinenumber){
        this.enrolleeForm_faxlinenumber = enrolleeForm_faxlinenumber;
    }
    public String getEnrolleeForm_faxlinenumber(){
        return this.enrolleeForm_faxlinenumber;
    }
    public void setEnrolleeForm_email(String enrolleeForm_email){
        this.enrolleeForm_email = enrolleeForm_email;
    }
    public String getEnrolleeForm_email(){
        return this.enrolleeForm_email;
    }
    public void setEnrolleeForm_emailverify(String enrolleeForm_emailverify){
        this.enrolleeForm_emailverify = enrolleeForm_emailverify;
    }
    public String getEnrolleeForm_emailverify(){
        return this.enrolleeForm_emailverify;
    }
    public void setEnrolleeForm_accept(String enrolleeForm_accept){
        this.enrolleeForm_accept = enrolleeForm_accept;
    }
    public String getEnrolleeForm_accept(){
        return this.enrolleeForm_accept;
    }
    public void setEnrolleeForm_acknowledge(String enrolleeForm_acknowledge){
        this.enrolleeForm_acknowledge = enrolleeForm_acknowledge;
    }
    public String getEnrolleeForm_acknowledge(){
        return this.enrolleeForm_acknowledge;
    }
    public void setEnrolleeForm_authorize(String enrolleeForm_authorize){
        this.enrolleeForm_authorize = enrolleeForm_authorize;
    }
    public String getEnrolleeForm_authorize(){
        return this.enrolleeForm_authorize;
    }

}
