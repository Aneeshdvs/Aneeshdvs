package com.mavp.pojos.locations;

public class Licenseform {
	private String licenseForm_ncpdpnumber;

    private String licenseForm_statelicense;

    private String licenseForm_state;

    public void setLicenseForm_ncpdpnumber(String licenseForm_ncpdpnumber){
        this.licenseForm_ncpdpnumber = licenseForm_ncpdpnumber;
    }
    public String getLicenseForm_ncpdpnumber(){
        return this.licenseForm_ncpdpnumber;
    }
    public void setLicenseForm_statelicense(String licenseForm_statelicense){
        this.licenseForm_statelicense = licenseForm_statelicense;
    }
    public String getLicenseForm_statelicense(){
        return this.licenseForm_statelicense;
    }
    public void setLicenseForm_state(String licenseForm_state){
        this.licenseForm_state = licenseForm_state;
    }
    public String getLicenseForm_state(){
        return this.licenseForm_state;
    }

}
