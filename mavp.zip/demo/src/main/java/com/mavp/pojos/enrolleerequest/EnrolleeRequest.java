package com.mavp.pojos.enrolleerequest;

public class EnrolleeRequest{
	
	 public String getFormName() {
		return formName;
	}
	public void setFormName(String formName) {
		this.formName = formName;
	}
	public RequestJSON getRequestJSON() {
		return requestJSON;
	}
	public void setRequestJSON(RequestJSON requestJSON) {
		this.requestJSON = requestJSON;
	}
	
	public String formName;
	 public RequestJSON requestJSON;
	 
	 public class RequestJSON{
		 
		   public AdditionalInfo getAdditionalinfo() {
			return additionalinfo;
		}

		public void setAdditionalinfo(AdditionalInfo additionalinfo) {
			this.additionalinfo = additionalinfo;
		}


		private AdditionalInfo additionalinfo;
		    private EnrolleeForm enrolleeform;
		   
		 


			 public EnrolleeForm getEnrolleeform() {
				return enrolleeform;
			}
          
			public void setEnrolleeform(EnrolleeForm enrolleeform) {
				this.enrolleeform = enrolleeform;
			}
			
			public class AdditionalInfo {
				
				private String success_target_url;
				private String error_page_url;
				private String enrollment_currentstep;
				private String enrollment_nextstep;
				private String enrollment_previousstep;
				
				public String getSuccess_target_url() {
					return success_target_url;
				}
				public void setSuccess_target_url(String success_target_url) {
					this.success_target_url = success_target_url;
				}
				public String getError_page_url() {
					return error_page_url;
				}
				public void setError_page_url(String error_page_url) {
					this.error_page_url = error_page_url;
				}
				public String getEnrollment_currentstep() {
					return enrollment_currentstep;
				}
				public void setEnrollment_currentstep(String enrollment_currentstep) {
					this.enrollment_currentstep = enrollment_currentstep;
				}
				public String getEnrollment_nextstep() {
					return enrollment_nextstep;
				}
				public void setEnrollment_nextstep(String enrollment_nextstep) {
					this.enrollment_nextstep = enrollment_nextstep;
				}
				public String getEnrollment_previousstep() {
					return enrollment_previousstep;
				}
				public void setEnrollment_previousstep(String enrollment_previousstep) {
					this.enrollment_previousstep = enrollment_previousstep;
				}
				
			}


            public class EnrolleeForm {

				private String enrolleeForm_organization;
				private String enrolleeForm_address1;
			    private String enrolleeForm_address2;
			    private String enrolleeForm_city;
			    private String enrolleeForm_state;
			    private String enrolleeForm_zip;
			    private String enrolleeForm_salutation;
			    private String enrolleeForm_professionaldesignation;
			    private String enrolleeForm_firstname;
			    private String enrolleeForm_middleinitial;
			    private String enrolleeForm_lastname;
			    private String enrolleeForm_generationalsuffix;
			    private String enrolleeForm_phoneareacode;
			    private String enrolleeForm_phoneexchange;
			    private String enrolleeForm_phonelinenumber;
			    private String enrolleeForm_faxareacode;
			    private String enrolleeForm_faxexchange;
			    private String enrolleeForm_faxlinenumber;
			    private String enrolleeForm_email;
			    private String enrolleeForm_emailverify;
			    private String enrolleeForm_accept;
			    private String enrolleeForm_acknowledge;
			    private String enrolleeForm_authorize;
			    
			    public String getEnrolleeForm_organization() {
					return enrolleeForm_organization;
				}
				public void setEnrolleeForm_organization(String enrolleeForm_organization) {
					this.enrolleeForm_organization = enrolleeForm_organization;
				}
				public String getEnrolleeForm_address1() {
					return enrolleeForm_address1;
				}
				public void setEnrolleeForm_address1(String enrolleeForm_address1) {
					this.enrolleeForm_address1 = enrolleeForm_address1;
				}
				public String getEnrolleeForm_address2() {
					return enrolleeForm_address2;
				}
				public void setEnrolleeForm_address2(String enrolleeForm_address2) {
					this.enrolleeForm_address2 = enrolleeForm_address2;
				}
				public String getEnrolleeForm_city() {
					return enrolleeForm_city;
				}
				public void setEnrolleeForm_city(String enrolleeForm_city) {
					this.enrolleeForm_city = enrolleeForm_city;
				}
				public String getEnrolleeForm_state() {
					return enrolleeForm_state;
				}
				public void setEnrolleeForm_state(String enrolleeForm_state) {
					this.enrolleeForm_state = enrolleeForm_state;
				}
				public String getEnrolleeForm_zip() {
					return enrolleeForm_zip;
				}
				public void setEnrolleeForm_zip(String enrolleeForm_zip) {
					this.enrolleeForm_zip = enrolleeForm_zip;
				}
				public String getEnrolleeForm_salutation() {
					return enrolleeForm_salutation;
				}
				public void setEnrolleeForm_salutation(String enrolleeForm_salutation) {
					this.enrolleeForm_salutation = enrolleeForm_salutation;
				}
				public String getEnrolleeForm_professionaldesignation() {
					return enrolleeForm_professionaldesignation;
				}
				public void setEnrolleeForm_professionaldesignation(String enrolleeForm_professionaldesignation) {
					this.enrolleeForm_professionaldesignation = enrolleeForm_professionaldesignation;
				}
				public String getEnrolleeForm_firstname() {
					return enrolleeForm_firstname;
				}
				public void setEnrolleeForm_firstname(String enrolleeForm_firstname) {
					this.enrolleeForm_firstname = enrolleeForm_firstname;
				}
				public String getEnrolleeForm_middleinitial() {
					return enrolleeForm_middleinitial;
				}
				public void setEnrolleeForm_middleinitial(String enrolleeForm_middleinitial) {
					this.enrolleeForm_middleinitial = enrolleeForm_middleinitial;
				}
				public String getEnrolleeForm_lastname() {
					return enrolleeForm_lastname;
				}
				public void setEnrolleeForm_lastname(String enrolleeForm_lastname) {
					this.enrolleeForm_lastname = enrolleeForm_lastname;
				}
				public String getEnrolleeForm_generationalsuffix() {
					return enrolleeForm_generationalsuffix;
				}
				public void setEnrolleeForm_generationalsuffix(String enrolleeForm_generationalsuffix) {
					this.enrolleeForm_generationalsuffix = enrolleeForm_generationalsuffix;
				}
				public String getEnrolleeForm_phoneareacode() {
					return enrolleeForm_phoneareacode;
				}
				public void setEnrolleeForm_phoneareacode(String enrolleeForm_phoneareacode) {
					this.enrolleeForm_phoneareacode = enrolleeForm_phoneareacode;
				}
				public String getEnrolleeForm_phoneexchange() {
					return enrolleeForm_phoneexchange;
				}
				public void setEnrolleeForm_phoneexchange(String enrolleeForm_phoneexchange) {
					this.enrolleeForm_phoneexchange = enrolleeForm_phoneexchange;
				}
				public String getEnrolleeForm_phonelinenumber() {
					return enrolleeForm_phonelinenumber;
				}
				public void setEnrolleeForm_phonelinenumber(String enrolleeForm_phonelinenumber) {
					this.enrolleeForm_phonelinenumber = enrolleeForm_phonelinenumber;
				}
				public String getEnrolleeForm_faxareacode() {
					return enrolleeForm_faxareacode;
				}
				public void setEnrolleeForm_faxareacode(String enrolleeForm_faxareacode) {
					this.enrolleeForm_faxareacode = enrolleeForm_faxareacode;
				}
				public String getEnrolleeForm_faxexchange() {
					return enrolleeForm_faxexchange;
				}
				public void setEnrolleeForm_faxexchange(String enrolleeForm_faxexchange) {
					this.enrolleeForm_faxexchange = enrolleeForm_faxexchange;
				}
				public String getEnrolleeForm_faxlinenumber() {
					return enrolleeForm_faxlinenumber;
				}
				public void setEnrolleeForm_faxlinenumber(String enrolleeForm_faxlinenumber) {
					this.enrolleeForm_faxlinenumber = enrolleeForm_faxlinenumber;
				}
				public String getEnrolleeForm_email() {
					return enrolleeForm_email;
				}
				public void setEnrolleeForm_email(String enrolleeForm_email) {
					this.enrolleeForm_email = enrolleeForm_email;
				}
				public String getEnrolleeForm_emailverify() {
					return enrolleeForm_emailverify;
				}
				public void setEnrolleeForm_emailverify(String enrolleeForm_emailverify) {
					this.enrolleeForm_emailverify = enrolleeForm_emailverify;
				}
				public String getEnrolleeForm_accept() {
					return enrolleeForm_accept;
				}
				public void setEnrolleeForm_accept(String enrolleeForm_accept) {
					this.enrolleeForm_accept = enrolleeForm_accept;
				}
				public String getEnrolleeForm_acknowledge() {
					return enrolleeForm_acknowledge;
				}
				public void setEnrolleeForm_acknowledge(String enrolleeForm_acknowledge) {
					this.enrolleeForm_acknowledge = enrolleeForm_acknowledge;
				}
				public String getEnrolleeForm_authorize() {
					return enrolleeForm_authorize;
				}
				public void setEnrolleeForm_authorize(String enrolleeForm_authorize) {
					this.enrolleeForm_authorize = enrolleeForm_authorize;
				}
				
			    
			}


		}
	



}
