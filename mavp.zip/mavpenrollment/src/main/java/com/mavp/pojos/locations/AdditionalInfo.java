package com.mavp.pojos.locations;

public class AdditionalInfo {
	
	private String success_target_url;
	private String error_page_url;
	private String enrollment_currentstep;
	private String enrollment_nextstep;
	private String enrollment_previousstep;
	
	public String getSuccess_target_url() {
		return success_target_url;
	}
	public void setSuccess_target_url(String success_target_url) {
		this.success_target_url = success_target_url;
	}
	public String getError_page_url() {
		return error_page_url;
	}
	public void setError_page_url(String error_page_url) {
		this.error_page_url = error_page_url;
	}
	public String getEnrollment_currentstep() {
		return enrollment_currentstep;
	}
	public void setEnrollment_currentstep(String enrollment_currentstep) {
		this.enrollment_currentstep = enrollment_currentstep;
	}
	public String getEnrollment_nextstep() {
		return enrollment_nextstep;
	}
	public void setEnrollment_nextstep(String enrollment_nextstep) {
		this.enrollment_nextstep = enrollment_nextstep;
	}
	public String getEnrollment_previousstep() {
		return enrollment_previousstep;
	}
	public void setEnrollment_previousstep(String enrollment_previousstep) {
		this.enrollment_previousstep = enrollment_previousstep;
	}
	

}
