package com.mavp.forms;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.regex.Pattern;

import org.json.JSONException;
import org.json.JSONObject;
import com.amazonaws.services.lambda.runtime.Context;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mavp.pojos.locations.LicenseandLocationinfoPojo;

public class LocationInfoForm {
	 
	public String LocationInfoJSON(LicenseandLocationinfoPojo event, Context context) throws JSONException {
		String response="";
		SortedMap <String,String> mapObject= new TreeMap<>();
		
		List<Object> li = new ArrayList<>();
		//Method to validate License info data
		String response1=locationinfoFormValidation(event, mapObject,li);
		System.out.println(li);
		//Method to validate & extract exact JSON data to send as response
		response = extractExactJSONtoPrint(event, response1, mapObject,li);
		return response;
		
	}

	private String extractExactJSONtoPrint(LicenseandLocationinfoPojo event, String response1,
			SortedMap<String, String> mapObject, List<Object> li2) throws JSONException {
		// TODO Auto-generated method stub
		
		JSONObject main5 = new JSONObject();
		
		ObjectMapper oMapper = new ObjectMapper();
		System.out.println("This came here");
		Map<String, String> map = oMapper.convertValue(event.getRequestJSON().getEnrolleeform(), Map.class);
		Map<String, String> map2 = oMapper.convertValue(event.getRequestJSON().getAdditionalrequest(), Map.class);
		System.out.println("this came here too");
		String jsonresponse = "";
		if (mapObject.isEmpty()) {
			map2.remove("error_page_url");
			main5.put("AdditionalResponse", map2);
			main5.put("Enrolleeform", map);
			main5.put("Locations", li2);
			jsonresponse= main5.toString();
		}
		else if(response1 == "Error Message"){
			main5.put("error_message", "You have submitted empty form. Please enter all the necessary fields.");
			jsonresponse = main5.toString();
		}
		else {
			map2.remove("success_target_url");
			main5.put("AdditionalResponse", map2);
			main5.put("Enrolleeform", map);
			System.out.println("Helloo aneesh");
			main5.put("Locations", li2);
			main5.put("error_message", mapObject);
			
			jsonresponse = main5.toString();
			System.out.println("Hello All");
		}
		return jsonresponse;
		
		
	}
	
	

	private String locationinfoFormValidation(LicenseandLocationinfoPojo event, SortedMap<String, String> mapObject,
			List<Object> li) throws JSONException {
		
		SortedMap<String,String>  map2 =  new TreeMap<>();
		SortedMap<String,String>  map3 =  new TreeMap<>();
		JSONObject main2 = new JSONObject();
		
		String Response = "";
		if(event.getRequestJSON().getLocations().isEmpty()) {
        	Response = "Error Message";
		}
		else {
			
			for (int i=0; i<event.getRequestJSON().getLocations().size();i++) {
				
				   String ncpdpnumber= event.getRequestJSON().getLocations().get(i).getLicenseform().getLicenseForm_ncpdpnumber();
				   map2.put("licenseForm_ncpdpnumber", ncpdpnumber);
			       String state= event.getRequestJSON().getLocations().get(i).getLicenseform().getLicenseForm_state();
			       map2.put("licenseForm_state", state);
			       String statelicense= event.getRequestJSON().getLocations().get(i).getLicenseform().getLicenseForm_statelicense();
			       map2.put("licenseForm_statelicense", statelicense);
		           
		  
		           String locationname = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationname();
		           map3.put("locationInfoForm_locationname", locationname);
		           String locationaddress1 = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationaddress1();
		           map3.put("locationInfoForm_locationaddress1", locationaddress1);
		           String locationaddress2 = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationaddress2();
		           map3.put("locationInfoForm_locationaddress2", locationaddress2);
		           String locationcity = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationcity();
		           map3.put("locationInfoForm_locationcity", locationcity);
		           String locationstate = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationstate();
		           map3.put("locationInfoForm_locationstate", locationstate);
                   String locationzip = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationzip();
                   map3.put("locationInfoForm_locationzip", locationzip);
                   String locationphoneareacode = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationphoneareacode();
                   map3.put("locationInfoForm_locationphoneareacode", locationphoneareacode);
                   String locationphoneexchange = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationphoneexchange();
                   map3.put("locationInfoForm_locationphoneexchange", locationphoneexchange);
                   String locationphonelinenumber = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationphonelinenumber();
                   map3.put("locationInfoForm_locationphonelinenumber", locationphonelinenumber);
                   String locationfaxareacode = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationfaxareacode();
                   map3.put("locationInfoForm_locationfaxareacode", locationfaxareacode);
                   String locationfaxexchange = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationfaxexchange();
                   map3.put("locationInfoForm_locationfaxexchange", locationfaxexchange);
                   String locationfaxlinenumber = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationfaxlinenumber();
                   map3.put("locationInfoForm_locationfaxlinenumber", locationfaxlinenumber);
                   String locationtype = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationtype();
                   map3.put("locationInfoForm_locationtype", locationtype);
                   String websiteurl = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_websiteurl();
                   map3.put("locationInfoForm_websiteurl", websiteurl);
                   String vspname = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_vspname();
                   map3.put("locationInfoForm_vspname", vspname);
		           

		           
		           String contactsalutation = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_salutation();
		           map3.put("contactInfoForm_salutation", contactsalutation);
		           String contactfirstname = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_firstname();
		           map3.put("contactInfoForm_firstname", contactfirstname);
		           String contactmiddleinitial = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_middleinitial();
		           map3.put("contactInfoForm_middleinitial", contactmiddleinitial);
		           String contactlastname = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_lastname();
		           map3.put("contactInfoForm_lastname", contactlastname);
		           String contactgenerationalsuffix = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_generationalsuffix();
		           map3.put("contactInfoForm_professionaldesignation", contactgenerationalsuffix);
		           String contactprofessionaldesignation =event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_professionaldesignation();
		           map3.put("contactInfoForm_generationalsuffix", contactprofessionaldesignation);
		           String contactaddress1 = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactaddress1();
		           map3.put("contactInfoForm_contactaddress1", contactaddress1);
		           String contactaddress2 = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactaddress2();
		           map3.put("contactInfoForm_contactaddress2", contactaddress2);
		           
		           String contactcity = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactcity();
		           map3.put("contactInfoForm_contactcity", contactcity);
		           String contactstate = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactstate();
		           map3.put("contactInfoForm_contactstate", contactstate);
		           String contactzip =event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactzip();
		           map3.put("contactInfoForm_contactzip", contactzip);
		           String contactphoneareacode = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactphoneareacode();
		           map3.put("contactInfoForm_contactphoneareacode", contactphoneareacode);
		           String contactphoneexchange = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactphoneexchange();
		           map3.put("contactInfoForm_contactphoneexchange", contactphoneexchange);
		           String contactphonelinenumber = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactphonelinenumber();
		           map3.put("contactInfoForm_contactphonelinenumber", contactphonelinenumber);
		           String contactfaxareacode = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactfaxareacode();
		           map3.put("contactInfoForm_contactfaxareacode", contactfaxareacode);
		           String contactfaxexchange = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactfaxexchange();
		           map3.put("contactInfoForm_contactfaxexchange", contactfaxexchange);
		           String contactfaxlinenumber = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactfaxlinenumber();
		           map3.put("contactInfoForm_contactfaxlinenumber", contactfaxlinenumber);
		           String contactemail = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_email();
		           map3.put("contactInfoForm_email", contactemail);
		           String contactemailverify = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_verifyemail();
		           map3.put("contactInfoForm_verifyemail", contactemailverify);

		           //Declare Error Flags for required fields
		           boolean errorFlag = false;
		           
		           boolean locationNameErrorFlag = false;
		           boolean locationNameCharErrorFlag = false;

		           boolean locationAddressErrorFlag = false;
		           boolean locationAddressCharErrorFlag = false;
		           boolean locationAddress2CharErrorFlag = false;
		           boolean locationCityErrorFlag = false;
		           boolean locationCityCharErrorFlag = false;

		           boolean locationStateErrorFlag = false;
		           boolean locationStateCharErrorFlag = false;

		           boolean locationZipErrorFlag = false;
		           boolean locationPhoneAreaCodeErrorFlag = false;
		           boolean locationPhoneExchangeErrorFlag = false;
		           boolean locationPhoneLineNumberErrorFlag = false;
		           boolean locationFaxAreaCodeErrorFlag = false;
		           boolean locationFaxExchangeErrorFlag = false;
		           boolean locationFaxLineNumberErrorFlag = false;
		           boolean locationTypeErrorFlag = false;
		           boolean locationTypeCharErrorFlag = false;

		           boolean websiteErrorFlag = false;
		           boolean vspNameCharErrorFlag = false;

		           
		           boolean contactFirstNameErrorFlag = false;
		           boolean contactLastNameErrorFlag = false;
		           boolean contactProfessionalDesignationErrorFlag = false;
		           boolean contactAddressErrorFlag = false;
		           boolean contactCityErrorFlag = false;
		           boolean contactStateErrorFlag = false;
		           boolean contactSalutationCharErrorFlag = false;
		           boolean contactFirstNameCharErrorFlag = false;
		           boolean contactMiddleInitialCharErrorFlag = false;
		           boolean contactLastNameCharErrorFlag = false;
		           boolean contactProfessionalDesignationCharErrorFlag = false;
		           boolean contactGenerationalSuffixCharErrorFlag = false;
		           boolean contactAddressCharErrorFlag = false;
		           boolean contactAddress2CharErrorFlag = false;
		           boolean contactCityCharErrorFlag = false;
		           boolean contactStateCharErrorFlag = false;
		           boolean contactZipErrorFlag = false;
		           boolean contactPhoneAreaCodeErrorFlag = false;
		           boolean contactPhoneExchangeErrorFlag = false;
		           boolean contactPhoneLineNumberErrorFlag = false;
		           boolean contactFaxAreaCodeErrorFlag = false;
		           boolean contactFaxExchangeErrorFlag = false;
		           boolean contactFaxLineNumberErrorFlag = false;
		           boolean contactEmailErrorFlag = false;
		           boolean contactEmailVerifyErrorFlag = false;
		           boolean contactEmailMismatchErrorFlag = false;
		           

		           
		           if(locationname.trim().isEmpty())
		           {
		               locationNameErrorFlag = true;
		               errorFlag = true;
		               if (locationNameErrorFlag=true) {
		               	mapObject.put("locationNameErrorFlag", "Location name is a required field");
		               }
		           }
		           if(isInvalidOrganization(locationname))
		           {
		               locationNameCharErrorFlag = true;
		               errorFlag = true;
		               if (locationNameCharErrorFlag=true) {
			               	mapObject.put("locationNameErrorFlag", "Location name should not contain special characters");
			               }
		           }
		           
		           if(locationaddress1.trim().isEmpty())
		           {
		               locationAddressErrorFlag = true;
		               errorFlag = true;
		               if (locationAddressErrorFlag=true) {
			               	mapObject.put("locationAddressErrorFlag", "Location address is a required field");
			               }
		           }
		           if(isSpecialChar(locationaddress1))
		           {
		               locationAddressCharErrorFlag = true;
		               errorFlag = true;
		               if (locationAddressCharErrorFlag=true) {
			               	mapObject.put("locationAddressCharErrorFlag", "Location address should not contain special characters");
			               }
		           }
		           if(isSpecialChar(locationaddress2))
		           {
		               locationAddress2CharErrorFlag = true;
		               errorFlag = true;
		               if (locationAddress2CharErrorFlag=true) {
			               	mapObject.put("locationAddress2CharErrorFlag", "Location address2 should not contain special characters");
			               }
		           }
		           if(locationcity.trim().isEmpty())
		           {
		               locationCityErrorFlag = true;
		               errorFlag = true;
		               if (locationCityErrorFlag=true) {
			               	mapObject.put("locationCityErrorFlag", "Location city is a required field");
			               }
		           }
		           if(isInvalidName(locationcity))
		           {
		               locationCityCharErrorFlag = true;
		               errorFlag = true;
		               if (locationCityCharErrorFlag=true) {
			               	mapObject.put("locationCityCharErrorFlag", "Location city should not contain special characters");
			               }
		               
		           }
		           
		           if(locationstate.trim().isEmpty())
		           {
		               locationStateErrorFlag = true;
		               errorFlag = true;
		               if (locationStateErrorFlag=true) {
			               	mapObject.put("locationStateErrorFlag", "Location state is a required field");
			               }
		           }
		           if(isSpecialChar(locationstate))
		           {
		               locationStateCharErrorFlag = true;
		               errorFlag = true;
		               if (locationStateCharErrorFlag=true) {
			               	mapObject.put("locationStateCharErrorFlag", "Location state should not contain special characters");
			               }
		           }
		           
		           //Check emptiness, 5 chars
		           if(locationzip.trim().isEmpty() || locationzip.length() != 5 || isNaN(locationzip))
		           {
		               locationZipErrorFlag = true;
		               errorFlag = true;
		               if (locationZipErrorFlag=true && locationzip.length() != 5) {
			               	mapObject.put("locationZipErrorFlag", "Location zip should contain 5 digits");
			               }
		               else {
		            	   mapObject.put("locationZipErrorFlag", "Location zip should be a number");
		               }
		           }
		           
		           //check for 3 digits
		           if(locationphoneareacode.trim().isEmpty() || locationphoneareacode.length() != 3 || isNaN(locationphoneareacode))
		           {
		               locationPhoneAreaCodeErrorFlag = true;
		               errorFlag = true;
		               if (locationPhoneAreaCodeErrorFlag=true && locationphoneareacode.trim().isEmpty()) {
		               	mapObject.put("locationPhoneAreaCodeErrorFlag", " phoneAreaCode is required field");
		               } else if (locationPhoneAreaCodeErrorFlag=true &&  locationphoneareacode.length() != 3){
		               	mapObject.put("locationPhoneAreaCodeErrorFlag", " phoneAreaCode should contain 3 characters");
		               } else {
		               	mapObject.put("locationPhoneAreaCodeErrorFlag", " phoneAreaCode should contain only numbers");
		               }
		           }
		           
		           //check for 3 digits
		           if(locationphoneexchange.trim().isEmpty() || locationphoneexchange.length() != 3 || isNaN(locationphoneexchange))
		           {
		               locationPhoneExchangeErrorFlag = true;
		               errorFlag = true;
		               if (locationPhoneExchangeErrorFlag=true && locationphoneexchange.trim().isEmpty()) {
			               	mapObject.put("locationPhoneExchangeErrorFlag", " phoneexchange is required field");
			               } else if (locationPhoneExchangeErrorFlag=true &&  locationphoneexchange.length() != 3){
			               	mapObject.put("locationPhoneExchangeErrorFlag", " phoneexchange should contain 3 characters");
			               } else {
			               	mapObject.put("locationPhoneExchangeErrorFlag", " phoneexchange should contain only numbers");
			               }
		           }
		           
		           //check for 4 digits
		           if(locationphonelinenumber.trim().isEmpty() || locationphonelinenumber.length() != 4 || isNaN(locationphonelinenumber))
		           {
		               locationPhoneLineNumberErrorFlag= true;
		               errorFlag = true;
		               if (locationPhoneLineNumberErrorFlag=true && locationphonelinenumber.trim().isEmpty()) {
			               	mapObject.put("locationPhoneLineNumberErrorFlag", " phonelinenumber is required field");
			               } else if (locationPhoneLineNumberErrorFlag=true &&  locationphonelinenumber.length() != 3){
			               	mapObject.put("locationPhoneLineNumberErrorFlag", " phonelinenumber should contain 3 characters");
			               } else {
			               	mapObject.put("locationPhoneLineNumberErrorFlag", " phonelinenumber should contain only numbers");
			               }
		           }
		           
		           //check for 3 digits in faxareacode and exchange 
		           if((!(locationfaxareacode.trim().isEmpty()) && locationfaxareacode.length() != 3) || isNaN(locationfaxareacode)||(locationfaxareacode.trim().isEmpty() &&(!(locationfaxexchange.trim().isEmpty())||!(locationfaxlinenumber.trim().isEmpty()))))
		           {
		               locationFaxAreaCodeErrorFlag = true;
		               errorFlag = true;
		               if (locationFaxAreaCodeErrorFlag=true && locationfaxareacode.trim().isEmpty()) {
			               	mapObject.put("locationFaxAreaCodeErrorFlag", " faxAreaCode is required field");
			               } else if (locationFaxAreaCodeErrorFlag=true &&  locationfaxareacode.length() != 3){
			               	mapObject.put("locationFaxAreaCodeErrorFlag", " faxAreaCode should contain 3 characters");
			               } else {
			               	mapObject.put("locationFaxAreaCodeErrorFlag", " faxAreaCode should contain only numbers");
			               }
		           }
		           
		           if((!(locationfaxexchange.trim().isEmpty()) && locationfaxexchange.length() != 3) || isNaN(locationfaxexchange)||(locationfaxexchange.trim().isEmpty() &&(!(locationfaxareacode.trim().isEmpty())||!(locationfaxlinenumber.trim().isEmpty()))))
		           {
		               locationFaxExchangeErrorFlag = true;
		               errorFlag = true;
		               if (locationFaxExchangeErrorFlag=true && locationfaxexchange.trim().isEmpty()) {
			               	mapObject.put("locationFaxExchangeErrorFlag", " faxexchange is required field");
			               } else if (locationFaxExchangeErrorFlag=true &&  locationfaxexchange.length() != 3){
			               	mapObject.put("locationFaxExchangeErrorFlag", " faxexchange should contain 3 characters");
			               } else {
			               	mapObject.put("locationFaxExchangeErrorFlag", " faxexchange should contain only numbers");
			               }
		           }
		           if((!(locationfaxlinenumber.trim().isEmpty()) && locationfaxlinenumber.length() != 4) || isNaN(locationfaxlinenumber)||(locationfaxlinenumber.trim().isEmpty() &&(!(locationfaxareacode.trim().isEmpty())||!(locationfaxexchange.trim().isEmpty()))))
		           {
		               locationFaxLineNumberErrorFlag = true;
		               errorFlag = true;
		               if (locationFaxLineNumberErrorFlag=true && locationfaxlinenumber.trim().isEmpty()) {
			               	mapObject.put("locationFaxLineNumberErrorFlag", " faxlinenumber is required field");
			               } else if (locationFaxLineNumberErrorFlag=true &&  locationfaxlinenumber.length() != 3){
			               	mapObject.put("locationFaxLineNumberErrorFlag", " faxlinenumber should contain 3 characters");
			               } else {
			               	mapObject.put("locationFaxLineNumberErrorFlag", " faxlinenumber should contain only numbers");
			               }
		           }
		           
		           if(locationtype.trim().isEmpty())
		           {
		               locationTypeErrorFlag = true;
		               errorFlag = true;
		               if (locationTypeErrorFlag=true) {
			               	mapObject.put("locationTypeErrorFlag", "Location type is required field");
			               }
		           }
		           if(isSpecialChar(locationtype))
		           {
		               locationTypeCharErrorFlag = true;
		               errorFlag = true;
		               if (locationTypeCharErrorFlag=true) {
			               	mapObject.put("locationTypeCharErrorFlag", "Location type should not contain special characters");
			               }
		           }
		           if(!(websiteurl.trim().isEmpty())) 
		           {
		               if(!isValidURL(websiteurl))
		               {
		                   websiteErrorFlag = true;
		                   errorFlag = true;
		                   if (websiteErrorFlag=true) {
				               	mapObject.put("websiteErrorFlag", "websiteurl is not a valid url");
				               }
		               }
		           }
		           if(isInvalidOrganization(vspname))
		           {
		               vspNameCharErrorFlag = true;
		               errorFlag = true;
		               if (vspNameCharErrorFlag=true) {
			               	mapObject.put("vspNameCharErrorFlag", "vsp name should not contain special characters");
			               }
		           }
		           if(isInvalidName(contactsalutation))
		           {
		               contactSalutationCharErrorFlag = true;
		               errorFlag = true;
		               if (contactSalutationCharErrorFlag=true) {
			               	mapObject.put("contactSalutationCharErrorFlag", " contactSalutation should not contain special characters");
			               }
		           }
		           if(contactfirstname.trim().isEmpty())
		           {
		               contactFirstNameErrorFlag = true;
		               errorFlag = true;
		               if (contactFirstNameErrorFlag=true) {
			               	mapObject.put("contactFirstNameErrorFlag", " firstname is a required field");
			               }
		           }
		           if(isInvalidName(contactfirstname))
		           {
		               contactFirstNameCharErrorFlag = true;
		               errorFlag = true;
		               if (contactFirstNameCharErrorFlag=true) {
			               	mapObject.put("contactFirstNameCharErrorFlag", " firstname should not contain special characters");
			               }
		           }
		           if(isInvalidName(contactmiddleinitial))
		           {
		               contactMiddleInitialCharErrorFlag = true;
		               errorFlag = true;
		               if (contactMiddleInitialCharErrorFlag=true) {
			               	mapObject.put("contactMiddleInitialCharErrorFlag", " Middle initial should not contain special characters");
			               }
		           }
		           if(contactlastname.trim().isEmpty())
		           {
		               contactLastNameErrorFlag = true;
		               errorFlag = true;
		               if (contactLastNameErrorFlag=true) {
			               	mapObject.put("contactLastNameErrorFlag", " Last name is a required field");
			               }
		           }
		           if(isInvalidName(contactlastname))
		           {
		               contactLastNameCharErrorFlag = true;
		               errorFlag = true;
		               if (contactLastNameCharErrorFlag=true) {
			               	mapObject.put("contactLastNameCharErrorFlag", " Last name should not contain special characters");
			               }
		           }
		           if(contactprofessionaldesignation.trim().isEmpty())
		           {
		               contactProfessionalDesignationErrorFlag = true;
		               errorFlag = true;
		               if (contactProfessionalDesignationErrorFlag=true) {
			               	mapObject.put("contactProfessionalDesignationErrorFlag", " ProfessionalDesignation is a required field");
			               }
		           }
		           if(isInvalidName(contactprofessionaldesignation))
		           {
		               contactProfessionalDesignationCharErrorFlag = true;
		               errorFlag = true;
		               if (contactProfessionalDesignationCharErrorFlag=true) {
			               	mapObject.put("contactProfessionalDesignationCharErrorFlag", " ProfessionalDesignation should not contain special characters");
			               }
		           }
		           if(isInvalidName(contactgenerationalsuffix))
		           {
		               contactGenerationalSuffixCharErrorFlag = true;
		               errorFlag = true;
		               if (contactGenerationalSuffixCharErrorFlag=true) {
			               	mapObject.put("contactGenerationalSuffixCharErrorFlag", " GenerationalSuffix should not contain special characters");
			               }
		           }
		           if(contactaddress1.trim().isEmpty())
		           {
		               contactAddressErrorFlag = true;
		               errorFlag = true;
		               if (contactAddressErrorFlag=true) {
			               	mapObject.put("contactAddressErrorFlag", " contactAddress is a required field");
			               }
		           }
		           if(isSpecialChar(contactaddress1))
		           {
		               contactAddressCharErrorFlag = true;
		               errorFlag = true;
		               if (contactAddressCharErrorFlag=true) {
			               	mapObject.put("contactAddressCharErrorFlag", " contactAddress should not contain special characters");
			               }
		           }
		           if(isSpecialChar(contactaddress2))
		           {
		               contactAddress2CharErrorFlag = true;
		               errorFlag = true;
		               if (contactAddress2CharErrorFlag=true) {
			               	mapObject.put("contactAddress2CharErrorFlag", " contactAddress2 should not contain special characters");
			               }
		           }
		           if(contactcity.trim().isEmpty())
		           {
		               contactCityErrorFlag = true;
		               errorFlag = true;
		               if (contactCityErrorFlag=true) {
			               	mapObject.put("contactCityErrorFlag", " contactCity is a required field");
			               }
		           }
		           if(isInvalidName(contactcity))
		           {
		               contactCityCharErrorFlag = true;
		               errorFlag = true;
		               if (contactCityCharErrorFlag=true) {
			               	mapObject.put("contactCityCharErrorFlag", " contactCity should not contain special characters");
			               }
		           }
		           if(contactstate.trim().isEmpty())
		           {
		               contactStateErrorFlag = true;
		               errorFlag = true;
		               if (contactStateErrorFlag=true) {
			               	mapObject.put("contactStateErrorFlag", " contactState is a required field");
			               }
		           }
		           if(isSpecialChar(contactstate))
		           {
		               contactStateCharErrorFlag = true;
		               errorFlag = true;
		               if (contactStateCharErrorFlag=true) {
			               	mapObject.put("contactStateCharErrorFlag", " contactState should not contain special characters");
			               }
		           }
		           
		           if(contactzip.trim().isEmpty() || contactzip.length() != 5 || isNaN(contactzip))
		           {
		               contactZipErrorFlag = true;
		               errorFlag = true;
		               if (contactZipErrorFlag=true && locationzip.length() != 5) {
			               	mapObject.put("contactZipErrorFlag", "contact zip should contain 5 digits");
			               }
		               else if(contactZipErrorFlag=true && isNaN(contactzip)) {
		            	   mapObject.put("contactZipErrorFlag", "contact zip should be a number");
		               }
		               else {
		            	   mapObject.put("contactZipErrorFlag", "contact zip is a required field");
		               }
		           }
		           
		         //check for 3 digits
		           if(contactphoneareacode.trim().isEmpty() || contactphoneareacode.length() != 3 || isNaN(contactphoneareacode))
		           {
		               contactPhoneAreaCodeErrorFlag = true;
		               errorFlag = true;
		               if (contactPhoneAreaCodeErrorFlag=true && contactphoneareacode.trim().isEmpty()) {
			               	mapObject.put("contactPhoneAreaCodeErrorFlag", " phoneAreaCode is required field");
			               } else if (contactPhoneAreaCodeErrorFlag=true &&  contactphoneareacode.length() != 3){
			               	mapObject.put("contactPhoneAreaCodeErrorFlag", " phoneAreaCode should contain 3 characters");
			               } else {
			               	mapObject.put("contactPhoneAreaCodeErrorFlag", " phoneAreaCode should contain only numbers");
			               }
		           }
		           
		           //check for 3 digits
		           if(contactphoneexchange.trim().isEmpty() || contactphoneexchange.length() != 3 || isNaN(contactphoneexchange))
		           {
		               contactPhoneExchangeErrorFlag = true;
		               errorFlag = true;
		               if (contactPhoneExchangeErrorFlag=true && contactphoneexchange.trim().isEmpty()) {
			               	mapObject.put("contactPhoneExchangeErrorFlag", " phoneexchange is required field");
			               } else if (contactPhoneExchangeErrorFlag=true &&  contactphoneexchange.length() != 3){
			               	mapObject.put("contactPhoneExchangeErrorFlag", " phoneexchange should contain 3 characters");
			               } else {
			               	mapObject.put("contactPhoneExchangeErrorFlag", " phoneexchange should contain only numbers");
			               }
		           }
		           
		           //check for 4 digits
		           if(contactphonelinenumber.trim().isEmpty() || contactphonelinenumber.length() != 4 || isNaN(contactphonelinenumber))
		           {
		               contactPhoneLineNumberErrorFlag= true;
		               errorFlag = true;
		               if (contactPhoneLineNumberErrorFlag=true && contactphonelinenumber.trim().isEmpty()) {
			               	mapObject.put("contactPhoneLineNumberErrorFlag", " phonelinenumber is required field");
			               } else if (contactPhoneLineNumberErrorFlag=true &&  contactphonelinenumber.length() != 3){
			               	mapObject.put("contactPhoneLineNumberErrorFlag", " phonelinenumber should contain 3 characters");
			               } else {
			               	mapObject.put("contactPhoneLineNumberErrorFlag", " phonelinenumber should contain only numbers");
			               }
		           }
		           
		           //check for 3 digits in faxareacode and exchange 
		           if((!(contactfaxareacode.trim().isEmpty()) && contactfaxareacode.length() != 3) || isNaN(contactfaxareacode)||(contactfaxareacode.trim().isEmpty() &&(!(contactfaxexchange.trim().isEmpty())||!(contactfaxlinenumber.trim().isEmpty()))))
		           {
		               contactFaxAreaCodeErrorFlag = true;
		               errorFlag = true;
		               if (contactFaxAreaCodeErrorFlag=true && contactfaxareacode.trim().isEmpty()) {
			               	mapObject.put("contactFaxAreaCodeErrorFlag", " faxAreaCode is required field");
			               } else if (contactFaxAreaCodeErrorFlag=true &&  contactfaxareacode.length() != 3){
			               	mapObject.put("contactFaxAreaCodeErrorFlag", " faxAreaCode should contain 3 characters");
			               } else {
			               	mapObject.put("contactFaxAreaCodeErrorFlag", " faxAreaCode should contain only numbers");
			               }
		           }
		           
		           if((!(contactfaxexchange.trim().isEmpty()) && contactfaxexchange.length() != 3) || isNaN(contactfaxexchange)||(contactfaxexchange.trim().isEmpty() &&(!(contactfaxareacode.trim().isEmpty())||!(contactfaxlinenumber.trim().isEmpty()))))
		           {
		               contactFaxExchangeErrorFlag = true;
		               errorFlag = true;
		               if (contactFaxExchangeErrorFlag=true && contactfaxexchange.trim().isEmpty()) {
			               	mapObject.put("contactFaxExchangeErrorFlag", " faxexchange is required field");
			               } else if (contactFaxExchangeErrorFlag=true &&  contactfaxexchange.length() != 3){
			               	mapObject.put("contactFaxExchangeErrorFlag", " faxexchange should contain 3 characters");
			               } else {
			               	mapObject.put("contactFaxExchangeErrorFlag", " faxexchange should contain only numbers");
			               }
		           }
		           if((!(contactfaxlinenumber.trim().isEmpty()) && contactfaxlinenumber.length() != 4) || isNaN(contactfaxlinenumber)||(contactfaxlinenumber.trim().isEmpty() &&(!(contactfaxareacode.trim().isEmpty())||!(contactfaxexchange.trim().isEmpty()))))
		           {
		               contactFaxLineNumberErrorFlag = true;
		               errorFlag = true;
		               if (contactFaxLineNumberErrorFlag=true && contactfaxlinenumber.trim().isEmpty()) {
			               	mapObject.put("contactFaxLineNumberErrorFlag", " faxlinenumber is required field");
			               } else if (contactFaxLineNumberErrorFlag=true &&  contactfaxlinenumber.length() != 3){
			               	mapObject.put("contactFaxLineNumberErrorFlag", " faxlinenumber should contain 3 characters");
			               } else {
			               	mapObject.put("contactFaxLineNumberErrorFlag", " faxlinenumber should contain only numbers");
			               }
		           }
		           
		           //check for valid email address
		           if(contactemail.trim().isEmpty() || !(isValid(contactemail)))
		           {
		               contactEmailErrorFlag = true;
		               errorFlag = true;
		               if (contactEmailErrorFlag=true && !(isValid(contactemail)) ) {
			               	mapObject.put("contactEmailErrorFlag", " Contact email is not a valid email");
			               }
		               else {
		            	   mapObject.put("contactEmailErrorFlag", " Contact email is a required field");
		               }
		           }
		           if(contactemailverify.trim().isEmpty() || !(isValid(contactemailverify)))
		           {
		               contactEmailVerifyErrorFlag = true;
		               errorFlag = true;
		               if (contactEmailVerifyErrorFlag=true && !(isValid(contactemail)) ) {
			               	mapObject.put("contactEmailVerifyErrorFlag", " Contact email is not a valid email");
			               }
		               else {
		            	   mapObject.put("contactEmailVerifyErrorFlag", " Contact email is a required field");
		               }
		           }
		           if(!contactEmailErrorFlag && !contactEmailVerifyErrorFlag) {
		               if(!(contactemail.equals(contactemailverify)))
		               {
		                   contactEmailMismatchErrorFlag = true;
		                   errorFlag = true;
		                   if (contactEmailMismatchErrorFlag=true) {
				               	mapObject.put("contactEmailMismatchErrorFlag", " Contact email is not matching. Please check once");
				               }
		                }
		           }
		           if (mapObject.isEmpty()) {
		           	Response = "";
		           }else {
		           	Response = "";
		           }
		           
		           main2.put("licenseform", map2);
		           main2.put("locationinfoform", map3);
				   li.add(main2);
			     
			}
			
		}
		
		return Response;
	}
	
	public boolean isValid(String email) //Strict Pattern Matching, beginning to end.
    { 
        if (email == null) 
            return false; 
        /*String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
                            "[a-zA-Z0-9_+&*-]+)*@" + 
                            "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
                            "A-Z]{2,7}$"; */
        String emailRegex = "^[a-zA-Z0-9_+&*-\\\\'\\\\`]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";

                              
        Pattern pat = Pattern.compile(emailRegex); 
        return pat.matcher(email).matches(); 
    } 
    public boolean isNaN(String num)
    {
        if(num == null)
            return true;
        String numberRegex = "[^\\d]+";
        Pattern pat = Pattern.compile(numberRegex);
        return pat.matcher(num).find();
    }
    
    
    public boolean strictSpecialCharCheck(String str)
    {
        //String specialCharRegex2 = "\\W+"; //If there are only special chars it is not a valid input
        //Pattern pat2 = Pattern.compile(specialCharRegex2);
        
        String specialCharRegex3 = "(?:&#x3C;|\\u003c|<).*?(?:&#x3E;|\\u003e|>);?"; //Strict pattern match against injected scripts and htmls
        Pattern pat3 = Pattern.compile(specialCharRegex3);
        
        String specialCharRegex4 = "(?:&#x3C;|\\u003c|&#x3E;|\\u003e|<|>)+";
        Pattern pat4 = Pattern.compile(specialCharRegex4);
        
        String specialCharRegex5 = "[^a-zA-Z\\p{L}\\p{M}\\p{N}]+";
        Pattern pat5 = Pattern.compile(specialCharRegex5, Pattern.UNICODE_CHARACTER_CLASS);
        
        //if(pat2.matcher(str.replaceAll("\\s", "")).matches() || pat3.matcher(str).find() || pat4.matcher(str).find() || pat5.matcher(str.replaceAll("\\s", "")).matches())
        if(pat3.matcher(str).find() || pat4.matcher(str).find() || pat5.matcher(str.replaceAll("\\s", "")).matches())
            return true;
        return false;
    }
    
    
    public boolean isInvalidName(String str)
    {
        str = str.trim();
        if(str == null || str.isEmpty())
            return false;
        String specialCharRegex = "[^-.,a-zA-Z\\s\\\\'\\\\`\\p{L}\\p{M}\\p{N}]+";
        Pattern pat1 = Pattern.compile(specialCharRegex, Pattern.UNICODE_CHARACTER_CLASS);
        
        if(pat1.matcher(str).find() || strictSpecialCharCheck(str))
            return true;
        return false;
    }
    
    
    
    public boolean isSpecialChar(String str)
    {
        str = str.trim();
        if(str == null || str.isEmpty())
            return false;
        String specialCharRegex = "[^-_,a-zA-Z0-9\\s\\\\'\\\\`\\.#&;\\/\\(\\)\\p{L}\\p{M}\\p{N}]+";
        Pattern pat1 = Pattern.compile(specialCharRegex, Pattern.UNICODE_CHARACTER_CLASS);
        
        if(pat1.matcher(str).find() || strictSpecialCharCheck(str))
            return true;
        return false;
    }
    
    
    public boolean isValidURL(String str) //Strict Pattern Matching, beginning to end.
    {
        if(str == null)
            return false;
        String urlRegex = "^(?:http(s)?:\\/\\/)?[\\w.-]+(?:\\.[\\w\\.-]+)+[\\w\\-\\._~:/?#\\[\\]@!\\$&'\\(\\)\\*\\+,;=.]+$";
        Pattern pat = Pattern.compile(urlRegex, Pattern.CASE_INSENSITIVE);
        return pat.matcher(str).matches();
    }
    
    public boolean isInvalidOrganization(String org)
    {
        org = org.trim();
        if(org == null || org.isEmpty())
            return false;
        String specialCharRegex = "[^-_,a-zA-Z0-9\\s\\\\'\\\\`\\.#&;\\/\\(\\)\\p{L}\\p{M}\\p{N}\\u2122\\u00A9\\u00AE]+"; 
        Pattern pat1 = Pattern.compile(specialCharRegex, Pattern.UNICODE_CHARACTER_CLASS);
        if(pat1.matcher(org).find() || strictSpecialCharCheck(org))
            return true;
        return false;
    }
  


}
