package com.mavp.pojos.locations;

import java.util.List;

public class RequestJSON {
	    private Enrolleeform enrolleeform;
	    private AdditionalRequest additionalrequest;
	    public AdditionalRequest getAdditionalrequest() {
			return additionalrequest;
		}
		public void setAdditionalrequest(AdditionalRequest additionalrequest) {
			this.additionalrequest = additionalrequest;
		}
		private List<Locations> locations;
     
	   
		
		public void setEnrolleeform(Enrolleeform enrolleeform){
	        this.enrolleeform = enrolleeform;
	    }
	    public Enrolleeform getEnrolleeform(){
	        return this.enrolleeform;
	    }
	    public void setLocations(List<Locations> locations){
	        this.locations = locations;
	    }
	    public List<Locations> getLocations(){
	        return this.locations;
	    }

}
