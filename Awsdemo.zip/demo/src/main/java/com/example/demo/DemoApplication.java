package com.example.demo;

import java.io.IOException;
import java.util.Map;


import com.amazonaws.services.lambda.runtime.*;


public class DemoApplication implements RequestHandler<Map<String,String>, String> {
	 
	public String handleRequest(Map<String,String> event, Context context) {
		
		 String jsonString = "{'NCPDP Number' : '', 'pharmacy state license number': '', 'State': ''}";
		 
		return jsonString ;
	}
}
