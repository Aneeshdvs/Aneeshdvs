package com.mavp.forms;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.regex.Pattern;

import org.json.JSONException;
import org.json.JSONObject;

import com.amazonaws.services.lambda.runtime.Context;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mavp.pojos.locations.LicenseandLocationinfoPojo;

public class licenseForm {
	
	public String LicenseJSON(LicenseandLocationinfoPojo event, Context context) {
		String response="";
		SortedMap <String,String> mapObject= new TreeMap<>();
		Map<String,String>  map2 =  new HashMap<String, String>();
		List<Object> li =  new ArrayList<Object>();
		try {
			//Method to validate License info data
			String response1=licenseFormValidation(event, mapObject,map2,li);
			System.out.println(li);
			//Method to validate & extract exact JSON data to send as response
			response = extractExactJSONtoPrint(event, response1, mapObject, li);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return response;
		
	}

   
	private String extractExactJSONtoPrint(LicenseandLocationinfoPojo event, String response1, SortedMap<String, String> mapObject, List<Object> li2 ) throws JSONException {
    	JSONObject main = new JSONObject();
    	ObjectMapper oMapper = new ObjectMapper();
		Map<String, String> map = oMapper.convertValue(event.getRequestJSON().getEnrolleeform(), Map.class);
		Map<String, String> map2 = oMapper.convertValue(event.getRequestJSON().getAdditionalinfo(), Map.class);
		String jsonresponse;
		if (mapObject.isEmpty()) {
			map2.remove("error_page_url");
			main.put("additionalinfo", map2);
			main.put("enrolleeform", map);
			main.put("locations", li2);
			jsonresponse= main.toString();
		}
		else if(response1 == "Error Message"){
			main.put("error_message", "You have submitted empty form. Please enter all the necessary fields.");
			System.out.println(main.toString());
			jsonresponse = main.toString();
		}
		else {
			map2.remove("success_target_url");
			main.put("additionalinfo", map2);
			main.put("enrolleeform", map);
			main.put("locations", li2);
			main.put("error_message", mapObject);
			System.out.println(main.toString());
			jsonresponse = main.toString();
		}
		return jsonresponse;
		
	}

	private String licenseFormValidation(LicenseandLocationinfoPojo event, SortedMap<String, String> mapObject, Map<String, String> map2, List<Object> li) throws JSONException {
		String Response = "";
		SortedMap<String,String>  map3 =  new TreeMap<>();
		JSONObject main2 = new JSONObject();
		SortedMap<String,String>  map4 =  new TreeMap<>();
		ObjectMapper oMapper = new ObjectMapper();
		if(event.getRequestJSON().getLocations().isEmpty()) {
        	Response = "Error Message";
		}
		else {
    	String ncpdpnumber="";
    	String statelicense="";
    	String state ="";
    	String s1="";
    	
    	for (int i=0; i<event.getRequestJSON().getLocations().size();i++) {
    	
    	//Map<String, String> map = oMapper.convertValue(event.getRequestJSON().getLocations().get(i).getLocationinfoform(), Map.class);
    	//Map<String, String> map4 = oMapper.convertValue(event.getRequestJSON().getLocations().get(i).getLicenseform(), Map.class);
    	
    	if (event.getRequestJSON().getLocations().get(i).getLocationinfoform()!=null &&
    			event.getRequestJSON().getLocations().get(i).getLicenseform()!=null) {
    		   System.out.println("printing first loop");
    		   ncpdpnumber= event.getRequestJSON().getLocations().get(i).getLicenseform().getLicenseForm_ncpdpnumber();
  	           map2.put("licenseForm_ncpdpnumber", ncpdpnumber);
  	           System.out.println(event.getRequestJSON().getLocations().get(i).getLicenseform().getLicenseForm_ncpdpnumber());
  	           state= event.getRequestJSON().getLocations().get(i).getLicenseform().getLicenseForm_state();
  	           map2.put("licenseForm_state", state);
  	           statelicense= event.getRequestJSON().getLocations().get(i).getLicenseform().getLicenseForm_statelicense();
  	           map2.put("licenseForm_statelicense", statelicense);
    		  
    		   String locationname = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationname();
	           map3.put("locationInfoForm_locationname", locationname);
	           String locationaddress1 = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationaddress1();
	           map3.put("locationInfoForm_locationaddress1", locationaddress1);
	           String locationaddress2 = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationaddress2();
	           map3.put("locationInfoForm_locationaddress2", locationaddress2);
	           String locationcity = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationcity();
	           map3.put("locationInfoForm_locationcity", locationcity);
	           String locationstate = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationstate();
	           map3.put("locationInfoForm_locationstate", locationstate);
               String locationzip = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationzip();
               map3.put("locationInfoForm_locationzip", locationzip);
               String locationphoneareacode = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationphoneareacode();
               map3.put("locationInfoForm_locationphoneareacode", locationphoneareacode);
               String locationphoneexchange = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationphoneexchange();
               map3.put("locationInfoForm_locationphoneexchange", locationphoneexchange);
               String locationphonelinenumber = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationphonelinenumber();
               map3.put("locationInfoForm_locationphonelinenumber", locationphonelinenumber);
               String locationfaxareacode = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationfaxareacode();
               map3.put("locationInfoForm_locationfaxareacode", locationfaxareacode);
               String locationfaxexchange = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationfaxexchange();
               map3.put("locationInfoForm_locationfaxexchange", locationfaxexchange);
               String locationfaxlinenumber = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationfaxlinenumber();
               map3.put("locationInfoForm_locationfaxlinenumber", locationfaxlinenumber);
               String locationtype = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_locationtype();
               map3.put("locationInfoForm_locationtype", locationtype);
               String websiteurl = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_websiteurl();
               map3.put("locationInfoForm_websiteurl", websiteurl);
               String vspname = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getLocationInfoForm_vspname();
               map3.put("locationInfoForm_vspname", vspname);
	           

	           
	           String contactsalutation = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_salutation();
	           map3.put("contactInfoForm_salutation", contactsalutation);
	           String contactfirstname = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_firstname();
	           map3.put("contactInfoForm_firstname", contactfirstname);
	           String contactmiddleinitial = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_middleinitial();
	           map3.put("contactInfoForm_middleinitial", contactmiddleinitial);
	           String contactlastname = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_lastname();
	           map3.put("contactInfoForm_lastname", contactlastname);
	           String contactgenerationalsuffix = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_generationalsuffix();
	           map3.put("contactInfoForm_professionaldesignation", contactgenerationalsuffix);
	           String contactprofessionaldesignation =event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_professionaldesignation();
	           map3.put("contactInfoForm_generationalsuffix", contactprofessionaldesignation);
	           String contactaddress1 = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactaddress1();
	           map3.put("contactInfoForm_contactaddress1", contactaddress1);
	           String contactaddress2 = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactaddress2();
	           map3.put("contactInfoForm_contactaddress2", contactaddress2);
	           
	           String contactcity = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactcity();
	           map3.put("contactInfoForm_contactcity", contactcity);
	           String contactstate = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactstate();
	           map3.put("contactInfoForm_contactstate", contactstate);
	           String contactzip =event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactzip();
	           map3.put("contactInfoForm_contactzip", contactzip);
	           String contactphoneareacode = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactphoneareacode();
	           map3.put("contactInfoForm_contactphoneareacode", contactphoneareacode);
	           String contactphoneexchange = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactphoneexchange();
	           map3.put("contactInfoForm_contactphoneexchange", contactphoneexchange);
	           String contactphonelinenumber = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactphonelinenumber();
	           map3.put("contactInfoForm_contactphonelinenumber", contactphonelinenumber);
	           String contactfaxareacode = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactfaxareacode();
	           map3.put("contactInfoForm_contactfaxareacode", contactfaxareacode);
	           String contactfaxexchange = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactfaxexchange();
	           map3.put("contactInfoForm_contactfaxexchange", contactfaxexchange);
	           String contactfaxlinenumber = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_contactfaxlinenumber();
	           map3.put("contactInfoForm_contactfaxlinenumber", contactfaxlinenumber);
	           String contactemail = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_email();
	           map3.put("contactInfoForm_email", contactemail);
	           String contactemailverify = event.getRequestJSON().getLocations().get(i).getLocationinfoform().getContactInfoForm_verifyemail();
	           map3.put("contactInfoForm_verifyemail", contactemailverify);
	           
	           main2.put("licenseform", map2);
	           main2.put("locationinfoform", map3);
	 		   li.add(main2);
	 		   System.out.println(li);
    		
    	}
    	else {
    		 
    		System.out.println("in the second loop");
    		   ncpdpnumber= event.getRequestJSON().getLocations().get(i).getLicenseform().getLicenseForm_ncpdpnumber();
    	       map4.put("licenseForm_ncpdpnumber", ncpdpnumber);
    	       System.out.println(event.getRequestJSON().getLocations().get(i).getLicenseform().getLicenseForm_ncpdpnumber());
    	       state= event.getRequestJSON().getLocations().get(i).getLicenseform().getLicenseForm_state();
    	       map4.put("licenseForm_state", state);
    	       statelicense= event.getRequestJSON().getLocations().get(i).getLicenseform().getLicenseForm_statelicense();
    	       map4.put("licenseForm_statelicense", statelicense);
    	    		
    	        boolean errorFlag = false;
    	        boolean ncpdpNumberErrorFlag = false;
    	        boolean stateLicenseErrorFlag = false;
    	        boolean stateErrorFlag = false;
    	        boolean stateLicenseCharErrorFlag = false;
    	        boolean duplicateNcpdpNumberErrorFlag = false;
    	        
    	      
    	        if(ncpdpnumber.trim().isEmpty() || ncpdpnumber.length() != 7 || isNaN(ncpdpnumber))
    	        {
    	            ncpdpNumberErrorFlag = true;
    	            errorFlag = true;
    	            if (ncpdpNumberErrorFlag=true && ncpdpnumber.trim().isEmpty()) {
    	            	mapObject.put("ncpdpNumberErrorFlag", "NCPDP Number is required field");
    	            }
    	            else if (ncpdpNumberErrorFlag=true && ncpdpnumber.length() != 7) {
    	            	mapObject.put("ncpdpNumberLengthErrorFlag", "NCPDP Number should contain 7 characters");
    	            } else {
    	            	mapObject.put("ncpdpNumberCharErrorFlag", "NCPDP Number should contain only numbers ");
    	            }
    	        }
    	        //Only check isEmpty
    	        if(statelicense.trim().isEmpty())
    	        {
    	            stateLicenseErrorFlag = true;
    	            errorFlag = true;
    	            if (stateLicenseErrorFlag=true) {
    	            	mapObject.put("stateLicenseErrorFlag", "State license is required field");
    	            }
    	        }
    	        if(isSpecialChar(statelicense))
    	        {
    	            stateLicenseCharErrorFlag = true;
    	            errorFlag = true;
    	            if (stateLicenseCharErrorFlag=true) {
    	            	mapObject.put("stateLicenseCharErrorFlag", "State license should not contain special characters");
    	            }
    	        }
    	        //Check emptiness
    	        if(state.trim().isEmpty())
    	        {
    	            stateErrorFlag = true;
    	            errorFlag = true;
    	            if (stateErrorFlag=true) {
    	            	mapObject.put("stateErrorFlag", "State is required field");
    	            }
    	        }
    	        if (mapObject.isEmpty()) {
    	        	Response = "";
    	        }else {
    	        	Response = "";
    	        }
    	        
    	       JSONObject main3 = new JSONObject();
			   main3.put("licenseform", map4);
    	       System.out.println(main3.toString());
      		   li.add(main3);
      		   System.out.println(li);
    		  }
    	}
	}
	
		return Response;
		
  }

	public boolean isNaN(String num)
    {
        if(num == null)
            return true;
        String numberRegex = "[^\\d]+";
        Pattern pat = Pattern.compile(numberRegex);
        return pat.matcher(num).matches();
    }
    
    public boolean isSpecialChar(String str)
    {
    	str = str.trim();
        if(str == null || str.isEmpty())
            return false;
        String specialCharRegex = "[^-_,a-zA-Z0-9\\s\\\\'\\\\`\\.#&;\\/\\(\\)\\p{L}\\p{M}\\p{N}]+"; 
        Pattern pat1 = Pattern.compile(specialCharRegex, Pattern.UNICODE_CHARACTER_CLASS);
        
        if(pat1.matcher(str).find() || strictSpecialCharCheck(str))
            return true;
        return false;
    }
    public boolean strictSpecialCharCheck(String str)
    {
        //String specialCharRegex2 = "\\W+"; //If there are only special chars it is not a valid input
        //Pattern pat2 = Pattern.compile(specialCharRegex2);
        
        String specialCharRegex3 = "(?:&#x3C;|\\u003c|<).*?(?:&#x3E;|\\u003e|>);?"; //Strict pattern match against injected scripts and htmls
        Pattern pat3 = Pattern.compile(specialCharRegex3);
        
        String specialCharRegex4 = "(?:&#x3C;|\\u003c|&#x3E;|\\u003e|<|>)+";
        Pattern pat4 = Pattern.compile(specialCharRegex4);
        
        String specialCharRegex5 = "[^a-zA-Z\\p{L}\\p{M}\\p{N}]+";
        Pattern pat5 = Pattern.compile(specialCharRegex5, Pattern.UNICODE_CHARACTER_CLASS);
        
        //if(pat2.matcher(str.replaceAll("\\s", "")).matches() || pat3.matcher(str).find() || pat4.matcher(str).find() || pat5.matcher(str.replaceAll("\\s", "")).matches())
        if(pat3.matcher(str).find() || pat4.matcher(str).find() || pat5.matcher(str.replaceAll("\\s", "")).matches())
            return true;
        return false;
    }
}
