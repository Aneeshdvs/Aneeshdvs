package com.mavp.handlerequest;

import org.json.JSONException;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.mavp.forms.EnrolleeForm;
import com.mavp.pojos.enrolleerequest.EnrolleeRequest;

public class MAVPHandleRequest implements RequestHandler<EnrolleeRequest, String>{
	
	public String handleRequest(EnrolleeRequest event, Context context) {
		String jsonResponse="";
			try {
				if (event.getFormName().contains("EnrolleeForm")) {
					EnrolleeForm ef = new EnrolleeForm();
				    jsonResponse= ef.EnrolleeJSON(event, context);
			    } 
			}
	         catch (JSONException e) {
				  e.printStackTrace();
			}
	
		return jsonResponse;
 
	}
	
}
