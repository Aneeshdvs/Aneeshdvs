package com.mavp.forms;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.regex.Pattern;

import org.json.JSONException;
import org.json.JSONObject;

import com.amazonaws.services.lambda.runtime.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mavp.pojos.enrolleerequest.EnrolleeRequest;


//Request Handler is the interface given by AWS lambda
 public class EnrolleeForm {
	 
	 public EnrolleeForm() {
		// TODO Auto-generated constructor stub
	}
	// Handle request is the method of Request handler Interface provided by AWS
	public String EnrolleeJSON(EnrolleeRequest event, Context context) throws JSONException {
		SortedMap <String,String> mapObject= new TreeMap<>();
		JSONObject main = new JSONObject();
		String json = null;
		try {
			//Method to validate enrollee info data
			String response=EnrolleeValidation(event, mapObject);
			//Method to validate & extract exact JSON data to send as response
			json = ExtractExactJSONtoPrint(response,event, mapObject);
		} catch (JSONException e) {
			e.printStackTrace();
		} 
		return json;
	}

	
	private String ExtractExactJSONtoPrint(String response, EnrolleeRequest event, SortedMap<String, String> mapObject) throws JSONException {
		String jsonresponse = "";
		JSONObject main = new JSONObject();
		ObjectMapper oMapper = new ObjectMapper();
		Map<String, String> map = oMapper.convertValue(event.getRequestJSON().getEnrolleeJSON(), Map.class);
		if (mapObject.isEmpty()) {
			
			main.put("EnrolleeForm", map);
			jsonresponse= main.toString();
		}
		else if(response == "Error Message"){
			main.put("error_message", "You have submitted empty form. Please enter all the necessary fields.");
			System.out.println(main.toString());
			jsonresponse = main.toString();
		}
		else {
			
			main.put("EnrolleeForm", map);
			main.put("error_message", mapObject);
			System.out.println(main.toString());
			jsonresponse = main.toString();
		}
		return jsonresponse;
	}



	
	
	private  String EnrolleeValidation(EnrolleeRequest event, SortedMap<String, String> mapObject) throws JSONException {
		String Response="";
		if (event.getRequestJSON().getEnrolleeJSON()!=null){
		String enrolleeForm_organization = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_organization();
		System.out.println("enrolleeForm_organization");
		String enrolleeForm_address1 = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_address1();
		String enrolleeForm_address2 = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_address2();
		String enrolleeForm_city = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_city();
		String enrolleeForm_state = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_state();
		String enrolleeForm_zip = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_zip();
		String enrolleeForm_salutation = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_salutation();
		String enrolleeForm_professionaldesignation = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_professionaldesignation();
		String enrolleeForm_firstname = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_firstname();
		String enrolleeForm_middleinitial = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_middleinitial();
		String enrolleeForm_lastname = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_lastname();
		String enrolleeForm_generationalsuffix = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_generationalsuffix();
		String enrolleeForm_phoneareacode = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_phoneareacode();
		String enrolleeForm_phoneexchange = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_phoneexchange();
		String enrolleeForm_phonelinenumber = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_phonelinenumber();
		String enrolleeForm_faxareacode = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_faxareacode();
		String enrolleeForm_faxexchange = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_faxexchange();
		String enrolleeForm_faxlinenumber = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_faxlinenumber();
		String enrolleeForm_email = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_email();
		String enrolleeForm_emailverify = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_emailverify();
		String enrolleeForm_accept = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_accept();
		String enrolleeForm_acknowledge = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_acknowledge();
		String enrolleeForm_authorize = event.getRequestJSON().getEnrolleeJSON().getEnrolleeForm_authorize();
		
		
		//Declare isEmptyFlags for required fields
        boolean errorFlag = false;
        boolean organizationIsEmptyFlag = false;
        boolean addressIsEmptyFlag = false;
        boolean cityIsEmptyFlag = false;
        boolean stateIsEmptyFlag = false;
        boolean zipIsEmptyFlag = false;
        boolean professionalDesignationIsEmptyFlag = false;
        boolean firstNameIsEmptyFlag = false;
        boolean lastNameIsEmptyFlag = false;
        boolean phoneAreaCodeIsEmptyFlag = false;
        boolean phoneExchangeIsEmptyFlag = false;
        boolean phoneLineNumberIsEmptyFlag = false;
        boolean faxAreaCodeIsEmptyFlag = false;
        boolean faxExchangeIsEmptyFlag = false;
        boolean faxLineNumberIsEmptyFlag = false;
        boolean emailIsEmptyFlag = false;
        boolean emailVerifyIsEmptyFlag = false;
        boolean acceptErrorFlag = false;
        boolean acknowledgeErrorFlag = false;
        boolean authorizeErrorFlag = false;
        boolean emailMismatchErrorFlag = false;
        
        boolean organizationCharErrorFlag = false;
        boolean address1CharErrorFlag = false;
        boolean cityCharErrorFlag = false;
        boolean stateCharErrorFlag = false;
        boolean firstNameCharErrorFlag = false;
        boolean lastNameCharErrorFlag = false;
        boolean professionalDesignationCharErrorFlag = false;
        
        boolean address2CharErrorFlag = false;
        boolean salutationCharErrorFlag = false;
        boolean middleInitialCharErrorFlag = false;
        boolean generationalSuffixCharErrorFlag = false;

        
       
        
        //Only check isEmpty
        if(enrolleeForm_organization.trim().isEmpty())
        {
            organizationIsEmptyFlag = true;
            errorFlag = true;
            if (organizationIsEmptyFlag=true) {
            	mapObject.put("organizationIsEmptyFlag", "Organization is required field");
            }
        }
        if(isInvalidOrganization(enrolleeForm_organization))
        {
            organizationCharErrorFlag = true;
            errorFlag = true;
            if (organizationCharErrorFlag=true) {
            	mapObject.put("organizationCharErrorFlag", "Organization should not contain special characters");
            }
        }
        //Only check isEmpty
        if(enrolleeForm_address1.trim().isEmpty())
        {
            addressIsEmptyFlag = true;
            errorFlag = true;
            if (addressIsEmptyFlag=true) {
            	mapObject.put("addressIsEmptyFlag", "Address is required field");
            }
        }
        if(isSpecialChar(enrolleeForm_address1))
        {
            address1CharErrorFlag = true;
            errorFlag = true;
            if (address1CharErrorFlag=true) {
            	mapObject.put("address1CharErrorFlag", "Address should not contain special characters");
            }
        }
        if(isSpecialChar(enrolleeForm_address2))
        {
            address2CharErrorFlag = true;
            errorFlag = true;
            if (address2CharErrorFlag=true) {
            	mapObject.put("address2CharErrorFlag", "Address should not contain special characters");
            }
        }
        //Only check isEmpty
        if(enrolleeForm_city.trim().isEmpty())
        {
            cityIsEmptyFlag = true;
            errorFlag = true;
            if (cityIsEmptyFlag=true) {
            	mapObject.put("cityIsEmptyFlag", "City is required field");
            }
            
        }
        if(isInvalidName(enrolleeForm_city))
        {
            cityCharErrorFlag = true;
            errorFlag = true;
            if (cityCharErrorFlag=true) {
            	mapObject.put("cityCharErrorFlag", "City should not contain special characters");
            }
        }
        //Only check isEmpty
        if(enrolleeForm_state.trim().isEmpty())
        {
            stateIsEmptyFlag = true;
            errorFlag = true;
            if (stateIsEmptyFlag=true) {
            	mapObject.put("stateIsEmptyFlag", "State is required field");
            }
        }
        if(isSpecialChar(enrolleeForm_state))
        {
            stateCharErrorFlag = true;
            errorFlag = true;
            if (stateCharErrorFlag=true) {
            	mapObject.put("stateCharErrorFlag", "State should not contain special characters");
            }
        }
        //Check emptiness, 5 chars
        if(enrolleeForm_zip.trim().isEmpty() || enrolleeForm_zip.length() != 5 || isNaN(enrolleeForm_zip))
        {
            zipIsEmptyFlag = true;
            errorFlag = true;
            if (zipIsEmptyFlag=true && enrolleeForm_zip.length() != 5 ) {
            	mapObject.put("zipLengthFlag", "Zip should contain exact 5 characters");
            }
            else if (zipIsEmptyFlag=true && enrolleeForm_zip.trim().isEmpty()) {
            	mapObject.put("zipIsEmptyFlag", "Zip is required field");
            }
            else {
            	mapObject.put("zipNumberFlag", "Zip is required field");
            }
        }
        if(isInvalidName(enrolleeForm_salutation))
        {
            salutationCharErrorFlag = true;
            errorFlag = true;
            if (salutationCharErrorFlag=true) {
            	mapObject.put("salutationCharErrorFlag", "Salutation should not contain special characters");
            }
        }
        //Only check isEmpty
        if(enrolleeForm_professionaldesignation.trim().isEmpty())
        {
            professionalDesignationIsEmptyFlag = true;
            errorFlag = true;
            if (professionalDesignationIsEmptyFlag=true) {
            	mapObject.put("professionalDesignationIsEmptyFlag", "professionalDesignation is required field");
            }
        }
        if(isInvalidName(enrolleeForm_professionaldesignation))
        {
            professionalDesignationCharErrorFlag = true;
            errorFlag = true;
            if (professionalDesignationCharErrorFlag=true) {
            	mapObject.put("professionalDesignationCharErrorFlag", "professionalDesignation should not contain special characters");
            }
        }
        //Only check isEmpty
        if(enrolleeForm_firstname.trim().isEmpty())
        {
            firstNameIsEmptyFlag = true;
            errorFlag = true;
            if (firstNameIsEmptyFlag=true) {
            	mapObject.put("firstNameIsEmptyFlag", " firstName is required field");
            }
        }
        if(isInvalidName(enrolleeForm_firstname))
        {
            firstNameCharErrorFlag = true;
            errorFlag = true;
            if (firstNameCharErrorFlag=true) {
            	mapObject.put("firstNameCharErrorFlag", " firstName should not contain special characters");
            }
        }
        if(isInvalidName(enrolleeForm_middleinitial))
        {
            middleInitialCharErrorFlag = true;
            errorFlag = true;
            if (middleInitialCharErrorFlag=true) {
            	mapObject.put("middleInitialCharErrorFlag", " middleInitial should not contain special characters");
            }
        }
      //Only check isEmpty
        if(enrolleeForm_lastname.trim().isEmpty())
        {
            lastNameIsEmptyFlag = true;
            errorFlag = true;
            if (lastNameIsEmptyFlag=true) {
            	mapObject.put("lastNameIsEmptyFlag", " lastName is required field");
            }
        }
        if(isInvalidName(enrolleeForm_lastname))
        {
            lastNameCharErrorFlag = true;
            errorFlag = true;
            if (lastNameCharErrorFlag=true) {
            	mapObject.put("lastNameCharErrorFlag", " lastName should not contain special characters");
            }
        }
        if(isInvalidName(enrolleeForm_generationalsuffix))
        {
            generationalSuffixCharErrorFlag = true;
            errorFlag = true;
            if (generationalSuffixCharErrorFlag=true) {
            	mapObject.put("generationalSuffixCharErrorFlag", " generationalSuffix should not contain special characters");
            }
        }
        //check for 3 digits
        if(enrolleeForm_phoneareacode.trim().isEmpty() || enrolleeForm_phoneareacode.length() != 3 || isNaN(enrolleeForm_phoneareacode))
        {
            phoneAreaCodeIsEmptyFlag = true;
            errorFlag = true;
            if (phoneAreaCodeIsEmptyFlag=true && enrolleeForm_phoneareacode.trim().isEmpty()) {
            	mapObject.put("phoneAreaCodeIsEmptyFlag", " phoneAreaCode is required field");
            } else if (phoneAreaCodeIsEmptyFlag=true &&  enrolleeForm_phoneareacode.length() != 3){
            	mapObject.put("phoneAreaCodeLengthFlag", " phoneAreaCode should contain 3 characters");
            } else {
            	mapObject.put("phoneAreaCodeNotNumberFlag", " phoneAreaCode should contain only numbers");
            }
        }
        //check for 3 digits
        if(enrolleeForm_phoneexchange.trim().isEmpty() || enrolleeForm_phoneexchange.length() != 3 || isNaN(enrolleeForm_phoneexchange))
        {
            phoneExchangeIsEmptyFlag = true;
            errorFlag = true;
            if (phoneExchangeIsEmptyFlag=true && enrolleeForm_phoneexchange.trim().isEmpty()) {
            	mapObject.put("phoneExchangeIsEmptyFlag", "phoneExchange is required field");
            } else if (phoneExchangeIsEmptyFlag=true &&  enrolleeForm_phoneexchange.length() != 3){
            	mapObject.put("phoneExchangeLengthFlag", " phoneExchange should contain 3 characters");
            } else {
            	mapObject.put("phoneExchangeNotNumberFlag", " phoneExchange should contain only numbers");
            }
        }
        //check for 4 minutes
        if(enrolleeForm_phonelinenumber.trim().isEmpty() || enrolleeForm_phonelinenumber.length() != 4 || isNaN(enrolleeForm_phonelinenumber))
        {
            phoneLineNumberIsEmptyFlag = true;
            errorFlag = true;
            if (phoneLineNumberIsEmptyFlag=true && enrolleeForm_phonelinenumber.trim().isEmpty()) {
            	mapObject.put("phoneLineNumberIsEmptyFlag", "phoneLineNumber is required field");
            } else if (phoneLineNumberIsEmptyFlag=true &&  enrolleeForm_phonelinenumber.length() != 4){
            	mapObject.put("phoneLineNumberLengthFlag", " phoneLineNumber should contain 4 characters");
            } else {
            	mapObject.put("phoneLineNumberNotNumberFlag", " phoneLineNumber should contain only numbers");
            }
        }
        //check for 3 digits in faxareacode and exchange 
        //check for 4 digits in faxlinenumber
        if((!(enrolleeForm_faxareacode.trim().isEmpty()) && enrolleeForm_faxareacode.length() != 3) || isNaN(enrolleeForm_faxareacode)||(enrolleeForm_faxareacode.trim().isEmpty() &&(!(enrolleeForm_faxexchange.trim().isEmpty())||!(enrolleeForm_faxlinenumber.trim().isEmpty()))))
        {
            faxAreaCodeIsEmptyFlag = true;
            errorFlag = true;
            if (faxAreaCodeIsEmptyFlag=true && enrolleeForm_faxareacode.trim().isEmpty()) {
            	mapObject.put("faxAreaCodeIsEmptyFlag", "faxAreaCode is required field");
            } else if (faxAreaCodeIsEmptyFlag=true &&  enrolleeForm_faxareacode.length() != 3){
            	mapObject.put("faxAreaCodeLengthFlag", " faxAreaCode should contain 3 characters");
            } else {
            	mapObject.put("faxAreaCodeNotNumberFlag", " faxAreaCode should contain only numbers");
            }
        }
        if((!(enrolleeForm_faxexchange.trim().isEmpty()) && enrolleeForm_faxexchange.length() != 3) || isNaN(enrolleeForm_faxexchange)||(enrolleeForm_faxexchange.trim().isEmpty() &&(!(enrolleeForm_faxareacode.trim().isEmpty())||!(enrolleeForm_faxlinenumber.trim().isEmpty()))))
        {
            faxExchangeIsEmptyFlag = true;
            errorFlag = true;
            if (faxExchangeIsEmptyFlag=true && enrolleeForm_faxexchange.trim().isEmpty()) {
            	mapObject.put("faxExchangeIsEmptyFlag", "faxExchange is required field");
            } else if (faxExchangeIsEmptyFlag=true &&  enrolleeForm_faxexchange.length() != 3){
            	mapObject.put("faxExchangeLengthFlag", " faxExchange should contain 3 characters");
            } else {
            	mapObject.put("faxExchangeNotNumberFlag", " faxExchange should contain only numbers");
            }
        }
        if((!(enrolleeForm_faxlinenumber.trim().isEmpty()) && enrolleeForm_faxlinenumber.length() != 4) || isNaN(enrolleeForm_faxlinenumber)||(enrolleeForm_faxlinenumber.trim().isEmpty() && (!(enrolleeForm_faxexchange.trim().isEmpty())||!(enrolleeForm_faxareacode.trim().isEmpty()))))
        {
            faxLineNumberIsEmptyFlag = true;
            errorFlag = true;
            if (faxLineNumberIsEmptyFlag=true && enrolleeForm_faxlinenumber.trim().isEmpty()) {
            	mapObject.put("faxLineNumberIsEmptyFlag", "faxLineNumber is required field");
            } else if (faxLineNumberIsEmptyFlag=true &&  enrolleeForm_faxlinenumber.length() != 4){
            	mapObject.put("faxLineNumberLengthFlag", " faxLineNumber should contain 4 characters");
            } else {
            	mapObject.put("faxLineNumberNotNumberFlag", " faxLineNumber should contain only numbers");
            }
        }
        //check for valid email address
        if(enrolleeForm_email.trim().isEmpty() || !(isValid(enrolleeForm_email)))
        {
            emailIsEmptyFlag = true;
            errorFlag = true;
            if (emailIsEmptyFlag=true && enrolleeForm_email.trim().isEmpty()) {
            	mapObject.put("emailIsEmptyFlag", "Email is required field");
            }
            else {
            	mapObject.put("emailvalidFlag", "Please enter valid email");
            }
        }
        
        //check for valid email address
        if(enrolleeForm_emailverify.trim().isEmpty() || !(isValid(enrolleeForm_emailverify)))
        {
            emailVerifyIsEmptyFlag = true;
            errorFlag = true;
            if (emailVerifyIsEmptyFlag=true && enrolleeForm_emailverify.trim().isEmpty()) {
            	mapObject.put("emailVerifyIsEmptyFlag", "EmailVerify is required field");
            }
            else {
            	mapObject.put("emailverifyvalidFlag", "Please enter valid email");
            }
        }
        //If no error in email or emailverify check for emails to match
        if(!emailIsEmptyFlag && !emailVerifyIsEmptyFlag){
            //check for emails to match
            if(!(enrolleeForm_email.equals(enrolleeForm_emailverify)))
            {
                emailMismatchErrorFlag = true;
                errorFlag = true;
                if (emailMismatchErrorFlag=true) {
                	mapObject.put("emailMismatchErrorFlag", "Email You entered didnot match");
                }
            }
        }
        
        //check for all 3 checkboxes
        if(enrolleeForm_accept == null /*|| accept.isEmpty()*/)
        {
            acceptErrorFlag = true;
            errorFlag = true;
            if (acceptErrorFlag=true) {
            	mapObject.put("acceptErrorFlag", "Please accept the enrollee form");
            }
        }
        if(enrolleeForm_acknowledge == null)
        {
            acknowledgeErrorFlag = true;
            errorFlag = true;
            if (acknowledgeErrorFlag=true) {
            	mapObject.put("acknowledgeErrorFlag", "Please acknowledge the enrollee form");
            }
        }
        if(enrolleeForm_authorize == null)
        {
            authorizeErrorFlag = true;
            errorFlag = true;
            if (authorizeErrorFlag=true) {
            	mapObject.put("authorizeErrorFlag", "Please authorize the enrollee form");
            }
        }
        
        if (mapObject.isEmpty()) {
        	Response = "";
        }
        else {
        	Response = "";
        }
		}
       return Response;
    }

	
	 public boolean isValid(String email) //Strict Pattern Matching, beginning to end.
	    { 
	        if (email == null) 
	            return false;  
	        /*String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
	                            "[a-zA-Z0-9_+&*-]+)*@" + 
	                            "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
	                            "A-Z]{2,7}$"; */
	        String emailRegex = "^[a-zA-Z0-9_+&*-\\\\'\\\\`]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";

	                              
	        Pattern pat = Pattern.compile(emailRegex); 
	        return pat.matcher(email).matches(); 
	    } 
	 
	 
	    public boolean isNaN(String num)
	    {
	        if(num == null)
	            return true;
	        String numberRegex = "[^\\d]+";
	        Pattern pat = Pattern.compile(numberRegex);
	        return pat.matcher(num).find();
	    }
	    
	    
	    public boolean strictSpecialCharCheck(String str)
	    {
	        //String specialCharRegex2 = "\\W+"; //If there are only special chars it is not a valid input
	        //Pattern pat2 = Pattern.compile(specialCharRegex2);
	        
	        String specialCharRegex3 = "(?:&#x3C;|\\u003c|<).*?(?:&#x3E;|\\u003e|>);?"; //Strict pattern match against injected scripts and htmls
	        Pattern pat3 = Pattern.compile(specialCharRegex3);
	        
	        String specialCharRegex4 = "(?:&#x3C;|\\u003c|&#x3E;|\\u003e|<|>)+";
	        Pattern pat4 = Pattern.compile(specialCharRegex4);
	        
	        String specialCharRegex5 = "[^a-zA-Z\\p{L}\\p{M}\\p{N}]+";
	        Pattern pat5 = Pattern.compile(specialCharRegex5, Pattern.UNICODE_CHARACTER_CLASS);
	        
	        //if(pat2.matcher(str.replaceAll("\\s", "")).matches() || pat3.matcher(str).find() || pat4.matcher(str).find() || pat5.matcher(str.replaceAll("\\s", "")).matches())
	        if(pat3.matcher(str).find() || pat4.matcher(str).find() || pat5.matcher(str.replaceAll("\\s", "")).matches())
	            return true;
	        return false;
	    }
	    
	    
	    public boolean isInvalidName(String str)
	    {
	        str = str.trim();
	        if(str == null || str.isEmpty())
	            return false;
	        String specialCharRegex = "[^-.,a-zA-Z\\s\\\\'\\\\`\\p{L}\\p{M}\\p{N}]+";
	        Pattern pat1 = Pattern.compile(specialCharRegex,  Pattern.UNICODE_CHARACTER_CLASS);
	        
	        if(pat1.matcher(str).find() || strictSpecialCharCheck(str))
	            return true;
	        return false;
	    }
	    
	    
	    
	    public boolean isSpecialChar(String str)
	    {
	        str = str.trim();
	        if(str == null || str.isEmpty())
	            return false;
	        String specialCharRegex = "[^-_,a-zA-Z0-9\\s\\\\'\\\\`\\.#&;\\/\\(\\)\\p{L}\\p{M}\\p{N}]+"; 
	        Pattern pat1 = Pattern.compile(specialCharRegex, Pattern.UNICODE_CHARACTER_CLASS);
	        
	        if(pat1.matcher(str).find() || strictSpecialCharCheck(str))
	            return true;
	        return false;
	    }
	    
	    
	    public boolean isInvalidOrganization(String org)
	    {
	        org = org.trim();
	        if(org == null || org.isEmpty())
	            return false;
	        String specialCharRegex = "[^-_,a-zA-Z0-9\\s\\\\'\\\\`\\.#&;\\/\\(\\)\\p{L}\\p{M}\\p{N}\\u2122\\u00A9\\u00AE]+"; 
	        Pattern pat1 = Pattern.compile(specialCharRegex, Pattern.UNICODE_CHARACTER_CLASS);
	        if(pat1.matcher(org).find() || strictSpecialCharCheck(org))
	            return true;
	        return false;
	    }
	    
	    

	
}
