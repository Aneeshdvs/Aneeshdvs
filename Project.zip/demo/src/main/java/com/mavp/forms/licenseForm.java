package com.mavp.forms;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.regex.Pattern;

import org.json.JSONException;
import org.json.JSONObject;

import com.amazonaws.services.lambda.runtime.Context;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mavp.pojos.licenseRequest.Request;

public class licenseForm {
	
	public String LicenseJSON(Request event, Context context) {
		String response="";
		SortedMap <String,String> mapObject= new TreeMap<>();
		Map<String,String>  map2 =  new HashMap<String, String>();
		try {
			//Method to validate License info data
			String response1=licenseFormValidation(event, mapObject,map2);
			//Method to validate & extract exact JSON data to send as response
			response = extractExactJSONtoPrint(event, response1, mapObject, map2);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return response;
		
	}

   
	private String extractExactJSONtoPrint(Request event, String response1, SortedMap<String, String> mapObject, Map<String, String> map2 ) throws JSONException {
    	JSONObject main = new JSONObject();
    	JSONObject main2 = new JSONObject();
    	List<Object> li = new ArrayList<>();
    	ObjectMapper oMapper = new ObjectMapper();
		Map<String, String> map = oMapper.convertValue(event.getRequestJSON().getEnrolleeForm(), Map.class);
		String jsonresponse;
		if (mapObject.isEmpty()) {
			main.put("Enrolleeform", map);
			main2.put("Licenseform", map2);
			li.add(main2);
			main.put("Locations", li);
			jsonresponse= main.toString();
		}
		else if(response1 == "Error Message"){
			main.put("error_message", "You have submitted empty form. Please enter all the necessary fields.");
			System.out.println(main.toString());
			jsonresponse = main.toString();
		}
		else {
			main.put("Enrolleeform", map);
			main2.put("Licenseform", map2);
			li.add(main2);
			main.put("Locations", li);
			main.put("error_message", mapObject);
			System.out.println(main.toString());
			jsonresponse = main.toString();
		}
		return jsonresponse;
		
	}

	private String licenseFormValidation(Request event, SortedMap<String, String> mapObject, Map<String, String> map2) {
		String Response = "";
		if(event.getRequestJSON().getLocations().isEmpty()) {
        	Response = "Error Message";
		}
		else {
    	String ncpdpnumber="";
    	String statelicense="";
    	String state ="";
    	String s1="";
    	
    	//Extracting license form from map object
    	
    	
    for (int i=0; i<event.getRequestJSON().getLocations().size();i++) {
    		
       ncpdpnumber= event.getRequestJSON().getLocations().get(i).getLicenseForm().getLicenseForm_ncpdpnumber();
       map2.put("licenseForm_ncpdpnumber", ncpdpnumber);
       System.out.println(event.getRequestJSON().getLocations().get(i).getLicenseForm().getLicenseForm_ncpdpnumber());
       state= event.getRequestJSON().getLocations().get(i).getLicenseForm().getLicenseForm_state();
       map2.put("licenseForm_state", state);
       statelicense= event.getRequestJSON().getLocations().get(i).getLicenseForm().getLicenseForm_statelicense();
       map2.put("licenseForm_statelicense", statelicense);
    		
        boolean errorFlag = false;
        boolean ncpdpNumberErrorFlag = false;
        boolean stateLicenseErrorFlag = false;
        boolean stateErrorFlag = false;
        boolean stateLicenseCharErrorFlag = false;
        boolean duplicateNcpdpNumberErrorFlag = false;
        
      
        if(ncpdpnumber.trim().isEmpty() || ncpdpnumber.length() != 7 || isNaN(ncpdpnumber))
        {
            ncpdpNumberErrorFlag = true;
            errorFlag = true;
            if (ncpdpNumberErrorFlag=true && ncpdpnumber.trim().isEmpty()) {
            	mapObject.put("ncpdpNumberErrorFlag", "NCPDP Number is required field");
            }
            else if (ncpdpNumberErrorFlag=true && ncpdpnumber.length() != 7) {
            	mapObject.put("ncpdpNumberLengthErrorFlag", "NCPDP Number should contain 7 characters");
            } else {
            	mapObject.put("ncpdpNumberCharErrorFlag", "NCPDP Number should contain only numbers ");
            }
        }
        //Only check isEmpty
        if(statelicense.trim().isEmpty())
        {
            stateLicenseErrorFlag = true;
            errorFlag = true;
            if (stateLicenseErrorFlag=true) {
            	mapObject.put("stateLicenseErrorFlag", "State license is required field");
            }
        }
        if(isSpecialChar(statelicense))
        {
            stateLicenseCharErrorFlag = true;
            errorFlag = true;
            if (stateLicenseCharErrorFlag=true) {
            	mapObject.put("stateLicenseCharErrorFlag", "State license should not contain special characters");
            }
        }
        //Check emptiness
        if(state.trim().isEmpty())
        {
            stateErrorFlag = true;
            errorFlag = true;
            if (stateErrorFlag=true) {
            	mapObject.put("stateErrorFlag", "State is required field");
            }
        }
        if (mapObject.isEmpty()) {
        	Response = "";
        }else {
        	Response = "";
        }
	}
		}
	
		return Response;
		
	}

	public boolean isNaN(String num)
    {
        if(num == null)
            return true;
        String numberRegex = "[^\\d]+";
        Pattern pat = Pattern.compile(numberRegex);
        return pat.matcher(num).matches();
    }
    
    public boolean isSpecialChar(String str)
    {
    	str = str.trim();
        if(str == null || str.isEmpty())
            return false;
        String specialCharRegex = "[^-_,a-zA-Z0-9\\s\\\\'\\\\`\\.#&;\\/\\(\\)\\p{L}\\p{M}\\p{N}]+"; 
        Pattern pat1 = Pattern.compile(specialCharRegex, Pattern.UNICODE_CHARACTER_CLASS);
        
        if(pat1.matcher(str).find() || strictSpecialCharCheck(str))
            return true;
        return false;
    }
    public boolean strictSpecialCharCheck(String str)
    {
        //String specialCharRegex2 = "\\W+"; //If there are only special chars it is not a valid input
        //Pattern pat2 = Pattern.compile(specialCharRegex2);
        
        String specialCharRegex3 = "(?:&#x3C;|\\u003c|<).*?(?:&#x3E;|\\u003e|>);?"; //Strict pattern match against injected scripts and htmls
        Pattern pat3 = Pattern.compile(specialCharRegex3);
        
        String specialCharRegex4 = "(?:&#x3C;|\\u003c|&#x3E;|\\u003e|<|>)+";
        Pattern pat4 = Pattern.compile(specialCharRegex4);
        
        String specialCharRegex5 = "[^a-zA-Z\\p{L}\\p{M}\\p{N}]+";
        Pattern pat5 = Pattern.compile(specialCharRegex5, Pattern.UNICODE_CHARACTER_CLASS);
        
        //if(pat2.matcher(str.replaceAll("\\s", "")).matches() || pat3.matcher(str).find() || pat4.matcher(str).find() || pat5.matcher(str.replaceAll("\\s", "")).matches())
        if(pat3.matcher(str).find() || pat4.matcher(str).find() || pat5.matcher(str.replaceAll("\\s", "")).matches())
            return true;
        return false;
    }
}
