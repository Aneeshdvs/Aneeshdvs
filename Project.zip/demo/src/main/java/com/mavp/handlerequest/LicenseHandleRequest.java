package com.mavp.handlerequest;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.mavp.forms.licenseForm;
import com.mavp.pojos.licenseRequest.Request;

public class LicenseHandleRequest implements RequestHandler<Request, String>{

	public String handleRequest(Request event, Context context) {
		String jsonResponse="";
			if (event.getFormName().contains("LicenseForm")) {
				System.out.println(event.getFormName().contains("LicenseForm"));
				System.out.println(event.getRequestJSON().getEnrolleeForm().getEnrolleeForm_phoneareacode());
				licenseForm ef = new licenseForm();
			    jsonResponse= ef.LicenseJSON(event, context);
			}
	
		return jsonResponse;
 
	}
	
}
