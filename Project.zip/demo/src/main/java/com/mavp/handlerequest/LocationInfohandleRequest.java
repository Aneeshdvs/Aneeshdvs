package com.mavp.handlerequest;

import org.json.JSONException;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.mavp.forms.LocationInfoForm;
import com.mavp.pojos.locationinforequest.Locationinforequest;

public class LocationInfohandleRequest implements RequestHandler<Locationinforequest, String> {

	
	public String handleRequest(Locationinforequest event, Context context) {
		String jsonResponse="";
			if (event.getFormName().contains("LocationInfoForm")) {
				LocationInfoForm ef = new LocationInfoForm();
				try {
					System.out.println(event.getRequestJSON().getEnrolleeform().getEnrolleeForm_phoneareacode());
					jsonResponse = ef.LocationInfoJSON(event, context);
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
	
		return jsonResponse;
 
	}
     
}
