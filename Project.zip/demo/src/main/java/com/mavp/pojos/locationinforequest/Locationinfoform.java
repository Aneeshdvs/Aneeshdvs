package com.mavp.pojos.locationinforequest;

public class Locationinfoform {
	private String locationInfoForm_locationname;

    private String locationInfoForm_locationaddress1;

    private String locationInfoForm_locationaddress2;

    private String locationInfoForm_locationcity;

    private String locationInfoForm_locationstate;

    private String locationInfoForm_locationzip;

    private String locationInfoForm_locationphoneareacode;

    private String locationInfoForm_locationphoneexchange;

    private String locationInfoForm_locationphonelinenumber;

    private String locationInfoForm_locationfaxareacode;

    private String locationInfoForm_locationfaxexchange;

    private String locationInfoForm_locationfaxlinenumber;

    private String locationInfoForm_locationtype;

    private String locationInfoForm_websiteurl;

    private String locationInfoForm_vspname;

    private String contactInfoForm_salutation;

    private String contactInfoForm_firstname;

    private String contactInfoForm_middleinitial;

    private String contactInfoForm_lastname;

    private String contactInfoForm_professionaldesignation;

    private String contactInfoForm_generationalsuffix;

    private String contactInfoForm_contactaddress1;

    private String contactInfoForm_contactaddress2;

    private String contactInfoForm_contactcity;

    private String contactInfoForm_contactstate;

    private String contactInfoForm_contactzip;

    private String contactInfoForm_contactphoneareacode;

    private String contactInfoForm_contactphoneexchange;

    private String contactInfoForm_contactphonelinenumber;

    private String contactInfoForm_contactfaxareacode;

    private String contactInfoForm_contactfaxexchange;

    private String contactInfoForm_contactfaxlinenumber;

    private String contactInfoForm_email;

    private String contactInfoForm_verifyemail;

    public void setLocationInfoForm_locationname(String locationInfoForm_locationname){
        this.locationInfoForm_locationname = locationInfoForm_locationname;
    }
    public String getLocationInfoForm_locationname(){
        return this.locationInfoForm_locationname;
    }
    public void setLocationInfoForm_locationaddress1(String locationInfoForm_locationaddress1){
        this.locationInfoForm_locationaddress1 = locationInfoForm_locationaddress1;
    }
    public String getLocationInfoForm_locationaddress1(){
        return this.locationInfoForm_locationaddress1;
    }
    public void setLocationInfoForm_locationaddress2(String locationInfoForm_locationaddress2){
        this.locationInfoForm_locationaddress2 = locationInfoForm_locationaddress2;
    }
    public String getLocationInfoForm_locationaddress2(){
        return this.locationInfoForm_locationaddress2;
    }
    public void setLocationInfoForm_locationcity(String locationInfoForm_locationcity){
        this.locationInfoForm_locationcity = locationInfoForm_locationcity;
    }
    public String getLocationInfoForm_locationcity(){
        return this.locationInfoForm_locationcity;
    }
    public void setLocationInfoForm_locationstate(String locationInfoForm_locationstate){
        this.locationInfoForm_locationstate = locationInfoForm_locationstate;
    }
    public String getLocationInfoForm_locationstate(){
        return this.locationInfoForm_locationstate;
    }
    public void setLocationInfoForm_locationzip(String locationInfoForm_locationzip){
        this.locationInfoForm_locationzip = locationInfoForm_locationzip;
    }
    public String getLocationInfoForm_locationzip(){
        return this.locationInfoForm_locationzip;
    }
    public void setLocationInfoForm_locationphoneareacode(String locationInfoForm_locationphoneareacode){
        this.locationInfoForm_locationphoneareacode = locationInfoForm_locationphoneareacode;
    }
    public String getLocationInfoForm_locationphoneareacode(){
        return this.locationInfoForm_locationphoneareacode;
    }
    public void setLocationInfoForm_locationphoneexchange(String locationInfoForm_locationphoneexchange){
        this.locationInfoForm_locationphoneexchange = locationInfoForm_locationphoneexchange;
    }
    public String getLocationInfoForm_locationphoneexchange(){
        return this.locationInfoForm_locationphoneexchange;
    }
    public void setLocationInfoForm_locationphonelinenumber(String locationInfoForm_locationphonelinenumber){
        this.locationInfoForm_locationphonelinenumber = locationInfoForm_locationphonelinenumber;
    }
    public String getLocationInfoForm_locationphonelinenumber(){
        return this.locationInfoForm_locationphonelinenumber;
    }
    public void setLocationInfoForm_locationfaxareacode(String locationInfoForm_locationfaxareacode){
        this.locationInfoForm_locationfaxareacode = locationInfoForm_locationfaxareacode;
    }
    public String getLocationInfoForm_locationfaxareacode(){
        return this.locationInfoForm_locationfaxareacode;
    }
    public void setLocationInfoForm_locationfaxexchange(String locationInfoForm_locationfaxexchange){
        this.locationInfoForm_locationfaxexchange = locationInfoForm_locationfaxexchange;
    }
    public String getLocationInfoForm_locationfaxexchange(){
        return this.locationInfoForm_locationfaxexchange;
    }
    public void setLocationInfoForm_locationfaxlinenumber(String locationInfoForm_locationfaxlinenumber){
        this.locationInfoForm_locationfaxlinenumber = locationInfoForm_locationfaxlinenumber;
    }
    public String getLocationInfoForm_locationfaxlinenumber(){
        return this.locationInfoForm_locationfaxlinenumber;
    }
    public void setLocationInfoForm_locationtype(String locationInfoForm_locationtype){
        this.locationInfoForm_locationtype = locationInfoForm_locationtype;
    }
    public String getLocationInfoForm_locationtype(){
        return this.locationInfoForm_locationtype;
    }
    public void setLocationInfoForm_websiteurl(String locationInfoForm_websiteurl){
        this.locationInfoForm_websiteurl = locationInfoForm_websiteurl;
    }
    public String getLocationInfoForm_websiteurl(){
        return this.locationInfoForm_websiteurl;
    }
    public void setLocationInfoForm_vspname(String locationInfoForm_vspname){
        this.locationInfoForm_vspname = locationInfoForm_vspname;
    }
    public String getLocationInfoForm_vspname(){
        return this.locationInfoForm_vspname;
    }
    public void setContactInfoForm_salutation(String contactInfoForm_salutation){
        this.contactInfoForm_salutation = contactInfoForm_salutation;
    }
    public String getContactInfoForm_salutation(){
        return this.contactInfoForm_salutation;
    }
    public void setContactInfoForm_firstname(String contactInfoForm_firstname){
        this.contactInfoForm_firstname = contactInfoForm_firstname;
    }
    public String getContactInfoForm_firstname(){
        return this.contactInfoForm_firstname;
    }
    public void setContactInfoForm_middleinitial(String contactInfoForm_middleinitial){
        this.contactInfoForm_middleinitial = contactInfoForm_middleinitial;
    }
    public String getContactInfoForm_middleinitial(){
        return this.contactInfoForm_middleinitial;
    }
    public void setContactInfoForm_lastname(String contactInfoForm_lastname){
        this.contactInfoForm_lastname = contactInfoForm_lastname;
    }
    public String getContactInfoForm_lastname(){
        return this.contactInfoForm_lastname;
    }
    public void setContactInfoForm_professionaldesignation(String contactInfoForm_professionaldesignation){
        this.contactInfoForm_professionaldesignation = contactInfoForm_professionaldesignation;
    }
    public String getContactInfoForm_professionaldesignation(){
        return this.contactInfoForm_professionaldesignation;
    }
    public void setContactInfoForm_generationalsuffix(String contactInfoForm_generationalsuffix){
        this.contactInfoForm_generationalsuffix = contactInfoForm_generationalsuffix;
    }
    public String getContactInfoForm_generationalsuffix(){
        return this.contactInfoForm_generationalsuffix;
    }
    public void setContactInfoForm_contactaddress1(String contactInfoForm_contactaddress1){
        this.contactInfoForm_contactaddress1 = contactInfoForm_contactaddress1;
    }
    public String getContactInfoForm_contactaddress1(){
        return this.contactInfoForm_contactaddress1;
    }
    public void setContactInfoForm_contactaddress2(String contactInfoForm_contactaddress2){
        this.contactInfoForm_contactaddress2 = contactInfoForm_contactaddress2;
    }
    public String getContactInfoForm_contactaddress2(){
        return this.contactInfoForm_contactaddress2;
    }
    public void setContactInfoForm_contactcity(String contactInfoForm_contactcity){
        this.contactInfoForm_contactcity = contactInfoForm_contactcity;
    }
    public String getContactInfoForm_contactcity(){
        return this.contactInfoForm_contactcity;
    }
    public void setContactInfoForm_contactstate(String contactInfoForm_contactstate){
        this.contactInfoForm_contactstate = contactInfoForm_contactstate;
    }
    public String getContactInfoForm_contactstate(){
        return this.contactInfoForm_contactstate;
    }
    public void setContactInfoForm_contactzip(String contactInfoForm_contactzip){
        this.contactInfoForm_contactzip = contactInfoForm_contactzip;
    }
    public String getContactInfoForm_contactzip(){
        return this.contactInfoForm_contactzip;
    }
    public void setContactInfoForm_contactphoneareacode(String contactInfoForm_contactphoneareacode){
        this.contactInfoForm_contactphoneareacode = contactInfoForm_contactphoneareacode;
    }
    public String getContactInfoForm_contactphoneareacode(){
        return this.contactInfoForm_contactphoneareacode;
    }
    public void setContactInfoForm_contactphoneexchange(String contactInfoForm_contactphoneexchange){
        this.contactInfoForm_contactphoneexchange = contactInfoForm_contactphoneexchange;
    }
    public String getContactInfoForm_contactphoneexchange(){
        return this.contactInfoForm_contactphoneexchange;
    }
    public void setContactInfoForm_contactphonelinenumber(String contactInfoForm_contactphonelinenumber){
        this.contactInfoForm_contactphonelinenumber = contactInfoForm_contactphonelinenumber;
    }
    public String getContactInfoForm_contactphonelinenumber(){
        return this.contactInfoForm_contactphonelinenumber;
    }
    public void setContactInfoForm_contactfaxareacode(String contactInfoForm_contactfaxareacode){
        this.contactInfoForm_contactfaxareacode = contactInfoForm_contactfaxareacode;
    }
    public String getContactInfoForm_contactfaxareacode(){
        return this.contactInfoForm_contactfaxareacode;
    }
    public void setContactInfoForm_contactfaxexchange(String contactInfoForm_contactfaxexchange){
        this.contactInfoForm_contactfaxexchange = contactInfoForm_contactfaxexchange;
    }
    public String getContactInfoForm_contactfaxexchange(){
        return this.contactInfoForm_contactfaxexchange;
    }
    public void setContactInfoForm_contactfaxlinenumber(String contactInfoForm_contactfaxlinenumber){
        this.contactInfoForm_contactfaxlinenumber = contactInfoForm_contactfaxlinenumber;
    }
    public String getContactInfoForm_contactfaxlinenumber(){
        return this.contactInfoForm_contactfaxlinenumber;
    }
    public void setContactInfoForm_email(String contactInfoForm_email){
        this.contactInfoForm_email = contactInfoForm_email;
    }
    public String getContactInfoForm_email(){
        return this.contactInfoForm_email;
    }
    public void setContactInfoForm_verifyemail(String contactInfoForm_verifyemail){
        this.contactInfoForm_verifyemail = contactInfoForm_verifyemail;
    }
    public String getContactInfoForm_verifyemail(){
        return this.contactInfoForm_verifyemail;
    }

}
