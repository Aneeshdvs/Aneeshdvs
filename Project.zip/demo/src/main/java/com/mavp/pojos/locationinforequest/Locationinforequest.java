package com.mavp.pojos.locationinforequest;

public class Locationinforequest {
	 private String formName;

	    private String addLocation;

	    private String submitLocation;

	    private RequestJSON requestJSON;

	    public void setFormName(String formName){
	        this.formName = formName;
	    }
	    public String getFormName(){
	        return this.formName;
	    }
	    public void setAddLocation(String addLocation){
	        this.addLocation = addLocation;
	    }
	    public String getAddLocation(){
	        return this.addLocation;
	    }
	    public void setSubmitLocation(String submitLocation){
	        this.submitLocation = submitLocation;
	    }
	    public String getSubmitLocation(){
	        return this.submitLocation;
	    }
	    public void setRequestJSON(RequestJSON requestJSON){
	        this.requestJSON = requestJSON;
	    }
	    public RequestJSON getRequestJSON(){
	        return this.requestJSON;
	    }

}
