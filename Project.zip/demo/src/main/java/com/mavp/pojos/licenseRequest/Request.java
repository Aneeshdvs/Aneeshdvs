package com.mavp.pojos.licenseRequest;

public class Request {
	 private String formName;

	    private RequestJSON requestJSON;

	    public void setFormName(String formName){
	        this.formName = formName;
	    }
	    public String getFormName(){
	        return this.formName;
	    }
	    public void setRequestJSON(RequestJSON requestJSON){
	        this.requestJSON = requestJSON;
	    }
	    public RequestJSON getRequestJSON(){
	        return this.requestJSON;
	    }
}
