package com.mavp.pojos.licenseRequest;

public class Locations {
	private LicenseForm LicenseForm;

    public void setLicenseForm(LicenseForm LicenseForm){
        this.LicenseForm = LicenseForm;
    }
    public LicenseForm getLicenseForm(){
        return this.LicenseForm;
    }

}
