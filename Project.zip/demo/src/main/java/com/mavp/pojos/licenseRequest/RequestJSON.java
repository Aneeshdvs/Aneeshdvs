package com.mavp.pojos.licenseRequest;

import java.util.List;

public class RequestJSON {
	private EnrolleeForm EnrolleeForm;

    private List<Locations> Locations;

    public void setEnrolleeForm(EnrolleeForm EnrolleeForm){
        this.EnrolleeForm = EnrolleeForm;
    }
    public EnrolleeForm getEnrolleeForm(){
        return this.EnrolleeForm;
    }
    public void setLocations(List<Locations> Locations){
        this.Locations = Locations;
    }
    public List<Locations> getLocations(){
        return this.Locations;
    }

}
