package com.mavp.pojos.locationinforequest;

import java.util.List;

public class RequestJSON {
	 private Enrolleeform enrolleeform;

	    private List<Locations> locations;

	    public void setEnrolleeform(Enrolleeform enrolleeform){
	        this.enrolleeform = enrolleeform;
	    }
	    public Enrolleeform getEnrolleeform(){
	        return this.enrolleeform;
	    }
	    public void setLocations(List<Locations> locations){
	        this.locations = locations;
	    }
	    public List<Locations> getLocations(){
	        return this.locations;
	    }

}
